filterCDFBatch <-
function(dataFolder, filterNoise = TRUE, mzListToFilter = c(1:30), output = "_noNoise", 
	limitScan, plotGraph = TRUE) {

	################### Check if valid folder ###########################
	validFolder <- function(pathFolder, errorMsg1, errorMsg2, titleMSG1) {
		if (is.character(pathFolder)) {
			isFolder <- file.access(as.character(pathFolder), 0)
			if (isFolder == 0) {
				isFolder <- file.info(pathFolder)
				if (isFolder$isdir == TRUE) {
					pathFolder <- pathFolder
				} else {
					dlgMessage(errorMsg2)
					pathFolder <- dlgDir(title = titleMSG1)$res
				}
			} else {
				dlgMessage(errorMsg2)
				pathFolder <- dlgDir(title = titleMSG1)$res
			}
		} else {
			### If not caharacter ###
			dlgMessage(errorMsg1)
			pathFolder <- dlgDir(title = titleMSG1)$res
		}
		return(pathFolder)
	}
	######################################################################
	titleMSG1 <- "Select the folder containing the GC-MS data in CDF format (NetCDF or AIA)."
	errorMsg1 <- "The dataFolder is not defined as character. A new window will open allowing you to select a valid folder."
	errorMsg2 <- "The dataFolder defined is not a valid folder. A new window will open allowing you to select a valid folder."

	if (missing(dataFolder)) {
		dataFolder <- dlgDir(title = titleMSG1)$res
	} else {
		dataFolder <- validFolder(dataFolder, errorMsg1, errorMsg2, titleMSG1)
	}

	### Search subfolders for defining experimental conditions #####
	expConditions <- file.info(list.files(dataFolder, full.names = TRUE))
	expConditions <- expConditions[expConditions$isdir == TRUE, ]
	### If no subfolders found ###
	if (nrow(expConditions) == 0) {
		dlgMessage("The dataFolder specified contains no subfolders defining experimental conditions. We will look for CDF files...")
		findCDF <- list.files(dataFolder, ".cdf", ignore.case = TRUE, full.names = TRUE)
		findCDFNames <- list.files(dataFolder, ".cdf", ignore.case = TRUE, full.names = FALSE)
		if (length(findCDF) == 0) {
			stop("There is no CDF files in the dataFolder specified.")
		}
		message("CDF files found...")
		expConditions <- as.numeric(dlgList(c(1:1000), title = "How many experimental conditions will be analyzed?")$res)
		findCDF <- data.frame(findCDF)
		for (i in 1:expConditions) {
			samples <- dlgList(findCDFNames, title = paste("Select the samples belonging to condition", 
				i), multiple = TRUE)$res
			findCDF[which(findCDFNames == samples), 2] <- paste("ExpCond_", i, sep = "")
		}
		replicates <- as.character(findCDF[, 2])
		reps <- factor(replicates)
		expConditions <- nlevels(reps)
	} else {
		findCDF <- c()
		message("Subfolders representing experimental conditions found...")
		subfolders <- data.frame(basename(row.names(expConditions)))
		names(subfolders)[1] <- "ExperimentalConditions"
		message(subfolders)
		for (i in 1:nrow(expConditions)) {
			findCDFpre <- list.files(row.names(expConditions[i, ]), ".cdf", ignore.case = TRUE, 
				full.names = TRUE)
			if (length(findCDFpre) == 0) {
				message(paste("The subfolder", basename(row.names(expConditions[i, ])), "contains no CDF files. It will not be considered in this analysis."))
			} else {
				findCDFpre <- data.frame(findCDFpre)
				findCDFpre[2] <- basename(row.names(expConditions[i, ]))
				findCDF <- rbind(findCDF, findCDFpre)
			}
		}
		replicates <- as.character(findCDF[, 2])
		reps <- factor(replicates)
		expConditions <- nlevels(reps)
	}

	validateMZLIST <- try(as.numeric(mzListToFilter), TRUE)
	if ("try-error" %in% class(validateMZLIST)) {
		dlgMessage("The mzListToFilter was not defined as a numerical list. It must be defined as a numeric list of fragments to be removed from the new CDF file that will be generated. A new dialog box will allow you to select the fragments.")
		validateMZLIST <- as.numeric(dlgList(c(1:1000), multiple = TRUE, title = "Select the fragments to be maintained.")$res)
	}

	for (i in 1:nrow(findCDF)) {
		if (missing(limitScan)) {
			message(paste("Analyzing sample ", as.character(findCDF[i,1]), sep = ""))
			raw_data <- filterCDF(as.character(findCDF[i, 1]), save = FALSE, filterNoise = filterNoise, mzListToFilter = mzListToFilter, output = output, plotGraph = plotGraph)
		} else {
			raw_data <- filterCDF(as.character(findCDF[i, 1]), save = FALSE, filterNoise = filterNoise, mzListToFilter = mzListToFilter, output = output, limitScan = limitScan, plotGraph = plotGraph)
		}
		folderToSave <- as.character(findCDF[i, 1])
		fileName <- basename(folderToSave)
		folderPath <- dirname(folderToSave)
		folderPath <- paste(folderPath, output, sep = "")
		fileNameparts <- unlist(strsplit(fileName, ".", fixed = TRUE))
		fileNameparts[length(fileNameparts)-1] <- paste(fileNameparts[length(fileNameparts)-1], output, sep = "")
		folderToSave <- file.path(folderPath, paste(fileNameparts, collapse = "."))
		
		isFolder <- file.access(as.character(folderPath), 0)
		if (isFolder == 0) {
			isFolder <- file.info(folderPath)
			if (isFolder$isdir == TRUE) {
				try(write.cdf(raw_data, folderToSave), TRUE)
			} else {
				dir.create(folderPath)
				try(write.cdf(raw_data, folderToSave), TRUE)
			}
		} else {
			dir.create(folderPath)
			try(write.cdf(raw_data, folderToSave), TRUE)
		}

	}
}
