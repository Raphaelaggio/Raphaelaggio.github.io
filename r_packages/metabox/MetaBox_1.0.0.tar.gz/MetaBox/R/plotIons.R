plotIons <-
function(data, ions = c(43, 54), RT = c(10,11), yscale, color, plotGraph = TRUE, plotAbundantIons = TRUE, numberOfIons = c(1), save = TRUE, folder, output = "fragments") {

	###########################################
	########## Check if save ##################
	###########################################
    if (save) {
        if (missing(folder)) {
            folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
        } else {
            if (is.character(folder)) {
                isFolder <- file.access(as.character(folder), 
                  0)
                if (isFolder == 0) {
                  isFolder <- file.info(folder)
                  if (isFolder$isdir != TRUE) {
                    dlgMessage("The folder defined to save the results is not a valid path.")
                    folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
                  }
                } else {
                  dlgMessage("The folder defined to save the results is not a valid path.")
                  folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
                }
            } else {
                dlgMessage("The path to the folder where the results will be saved must be specified as character.")
                folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
            }
        }
    }

	#######################################
	#### Choose CDF file with dialog ######
#######################################
isCDFdlg <- function(titleMSG, errorMSG) {
		t = 0
		while (t == 0) {
			checkIfCDF <- dlgOpen(title = titleMSG, multiple = FALSE)$res
			checkIfCDF2 <- basename(checkIfCDF)
			checkIfCDF3 <- unlist(strsplit(checkIfCDF2, "\\."))
			checkIfCDF4 <- checkIfCDF3[length(checkIfCDF3)]
			if (toupper(checkIfCDF4) == "CDF") {
				t = 1
				return(checkIfCDF)
			} else {
				dlgMessage(errorMSG)
			}
		}
	}
	#######################################
	## Choose CDF file with no dialog #####
#######################################
isCDF <- function(pathFile, errorMSG) {
		t = 0
		checkIfCDF <- pathFile
		checkIfCDF2 <- basename(checkIfCDF)
		checkIfCDF3 <- unlist(strsplit(checkIfCDF2, "\\."))
		checkIfCDF4 <- checkIfCDF3[length(checkIfCDF3)]
		if (toupper(checkIfCDF4) == "CDF") {
			t = 1
			return(t)
		} else {
			return(t)
		}
	}
	#######################################
	############# Load data ###############
#######################################
if (missing(data)) {
		data <- isCDFdlg("Select the CDF file containing the input data", "The input file MUST be in CDF format. Please, choose an input file showing the extension .cdf.")
		data <- xcmsRaw(data)
		message("Input file loaded...")
	} else {
		if (is.character(data)) {
			checkIfCDF <- isCDF(data)
			if (checkIfCDF == 1) {
				inputTest <- file.access(data, 0)
				if (inputTest == 0) {
					data <- xcmsRaw(data)
				} else {
					dlgMessage("The input file specified is not accessible. Please, choose a valid CDF file to be used as input data.")
					data <- isCDFdlg("Select the CDF file containing the input data", "The input file MUST be in CDF format. Please, choose an input file showing the extension .cdf.")
					data <- xcmsRaw(data)
					message("Input file loaded...")
				}
			} else {
				if (class(data)[1] == "xcmsRaw") {
					data <- data
					message("Input file loaded...")
				} else {
					dlgMessage("The input data must be specified as character string or as an object of class xcmsRaw. Please, choose a valid CDF file to be used as input data.")
					data <- isCDFdlg("Select the CDF file containing the input data", "The input file MUST be in CDF format. Please, choose an input file showing the extension .cdf.")
					data <- xcmsRaw(data)
					message("Input file loaded...")
				}
			}
		}
	}	
	#######################################
	######## Get RT to analyze ############
#######################################
	RT <- c(RT[1], RT[length(RT)])
	message("Processing data. Please wait...")
	#######################################
	######## Get intensity of ions ########
#######################################
dataPoints <- which(round(data@scantime, 0) >= round(RT[1] * 60, 0) & round(data@scantime, 0) <= round(RT[2] * 60, 0))
ScanGets <- function(data, points){
	result <- data.frame(getScan(data, points))
	result[1] <- round(result[, 1] * 2)/2
	names(result) <- c("mz", points)
	return(result)	
}
ScanDataPre <- lapply(as.list(dataPoints), function(x) ScanGets(data, x))       
mergeData <- function(x, y){
	merge(x,y,all=T,by="mz")
}
ScanDataPre <- Reduce(mergeData, ScanDataPre)

	#######################################
	############## Get yscale #############
#######################################
if (missing(yscale)) {
		yscale <- c(0, max(data@tic[dataPoints]))
	}
	#######################################
	####### Find abundant ions ############
#######################################

WholeData <- ScanDataPre

if (plotAbundantIons){
	intensities <- cbind(WholeData[,1], apply(WholeData[-1], 1, function(x) max(x, na.rm = TRUE)))
	intensities <- intensities[order(intensities[,2], decreasing = TRUE),]
	if (length(ions) != 0){
		intensities <- intensities[-which(as.numeric(intensities[,1]) %in% ions),]
	}
	if (missing(numberOfIons)){
		numberOfIons <- try(as.numeric(dlgList(1:1000, title = "How many additional ions to plot?")$res), TRUE)
		ions <- c(ions, intensities[c(1:numberOfIons), 1])
		ions <- ions[!duplicated(ions)]
	} else {
		ions <- c(ions, intensities[c(1:numberOfIons), 1])
		ions <- ions[!duplicated(ions)]
	}
}
	#######################################
	######## Get colors to use ############
#######################################
if (missing(color)) {
		color <- palette()[1:length(ions)]		
	} else {
		if (length(color) < length(ions)) {
			color <- rep(color, length(ions))
			color <- color[1:length(ions)]
		} else {
			if (length(color) > length(ions)) {
				color <- color[1:length(ions)]
			}
		}
	}
	###########################################
	#### Format names of WholeData ############
#######################################
names(WholeData) <- c("mz", round(data@scantime[as.numeric(names(WholeData)[-1])]/60, 3))

	###########################################
	############ Define devices ###############
###########################################
###### Function to add new device ########
	newDev <- function(size1 = 5, size2 = 5) {
		dev.new(width = size1, height = size2)
		invisible(dev.cur())
	}

	###########################################
	############ Plot chrom graph #############
###########################################
toPlot = c()
if (plotGraph) {
	chromPlot <- newDev(5, 5)
	dev.set(chromPlot)
		plot(data@scantime[dataPoints]/60, data@tic[dataPoints], type = "l", ylim = yscale, 
			col = "black", xlab = "RT(min)", ylab = "Intensity", main = "Ion Mass Fragments", 
			bty = "n", lty = 3)
		plotting <- apply(WholeData[-1], 1, function(x) lines(data@scantime[dataPoints]/60, x, type = "l", col = "grey", lwd = 2))
		specificMZ <- which(WholeData[, 1] %in% ions)
		colorToPlot <- color
		if (length(specificMZ) > 0) {
			for (i in 1:length(specificMZ)) {
				findColor <- which(ions == WholeData[specificMZ[i], 1])
				lines(data@scantime[dataPoints]/60, WholeData[specificMZ[i], -1], col = colorToPlot[findColor], 
					type = "l", lwd = 2)
			}
			try(legend("topleft", legend = c("TIC", ions), cex = 0.7, col = c("black", color), 
				lty = c(3,rep(1, length(ions))), title = "Fragments", lwd = 2, merge = FALSE, bg = "white", bty = "n"), TRUE)
		}	
									
	###########################################
	######## Select RT for spectrum ###########
###########################################
		dlgMessage("Click on a region of the chromatogram to obtain the spectrum. When you finished, click below the X axis to stop the function.")				
		findPoint <- locator(n = 1, type = "o", col = "red")
		findPointOld <- findPoint
		segments(as.numeric(findPoint[1]), as.numeric(findPoint[2]), as.numeric(findPoint[1]), 0, col = "red", lty = 3)
		text(as.numeric(findPoint[1]), as.numeric(findPoint[2]), labels = round(as.numeric(findPoint[1]), 3), pos = 2, srt = 90, col = "red", cex = 0.7)
		i <- 1
		if (as.numeric(findPoint[2]) > 0){
			spectrum <- newDev(5, 5)
		}
	###########################################
	######## Print spectrum continously #######
###########################################	
		while(as.numeric(findPoint[2]) > 0){
			if (i != 1){
				findPoint <- locator(n = 1, type = "o", col = "red")
				if (as.numeric(findPoint[2]) > 0){				
					for (k in 1:3){
						segments(as.numeric(findPointOld[1]), as.numeric(findPointOld[2]), as.numeric(findPointOld[1]), 0, col = "white", lty = 3)
						text(as.numeric(findPointOld[1]), as.numeric(findPointOld[2]), labels = round(as.numeric(findPointOld[1]), 3), pos = 2, srt = 90, col = "white", cex = 0.7)
						points(as.numeric(findPointOld[1]), as.numeric(findPointOld[2]), col = "white")
					}
					findPointOld <- findPoint
					segments(as.numeric(findPoint[1]), as.numeric(findPoint[2]), as.numeric(findPoint[1]), 0, col = "red", lty = 3)
					text(as.numeric(findPoint[1]), as.numeric(findPoint[2]), labels = round(as.numeric(findPoint[1]), 3), pos = 2, srt = 90, col = "red", cex = 0.7)
				}
			}
			if (as.numeric(findPoint[2]) > 0){
				pointToFind <- round(as.numeric(findPoint[1]), 3)
				pointToSearch <- as.numeric(names(WholeData[-1]))
				searchIn <- abs(pointToSearch - pointToFind)
				searchIn <- which(searchIn == min(searchIn, na.rm = TRUE))
				toPlot <- WholeData[,c(1, c(searchIn[1]+1))]
				toPlot <- toPlot[order(toPlot[,2], decreasing = TRUE),]
				toPlot <- toPlot[1:15,]
				toPlot <- toPlot[!is.na(toPlot[,2]),]
				toPlot <- toPlot[order(toPlot[,1], decreasing = FALSE),]
				toPlot[,2] <- (toPlot[,2])/(max(toPlot[,2], na.rm = TRUE))
				row.names(toPlot) <- toPlot[,1]
				toPlot <- toPlot[toPlot[,2] > 0.05,]
				toPlot <- toPlot[-1]			
				i <- i + 1
				dev.set(spectrum)
	###########################################
	############## Plot spectrum ##############
###########################################	
				par(xpd = TRUE)
				barplot(t(toPlot), beside = TRUE, axes = TRUE, cex.axis = 0.7, cex.names = 0.7, border = NA, main = paste("Spectrum RT: ", round(as.numeric(findPointOld[1]), 3), sep = ""), col = "black", ylab = "Intensity", xlab = "m/z", xpd = FALSE)
				xpos <- 1.5
				for (k in 1:nrow(toPlot)){
					text(xpos, as.numeric(toPlot[k,1]), labels = round(as.numeric(toPlot[k,1]),3), cex = 0.7, pos = 3)
					xpos <- xpos + 2
				}			
				dev.set(chromPlot)
			}
		}	
}
	###########################################
	############## save results ##############
###########################################
if (length(toPlot) != 0){
			toPlot[,1] <- round(as.numeric(toPlot[,1]),3)
		}	
	if (save) {
      store <- file.path(folder, paste(output, ".csv", sep = ""))
      write.csv(WholeData, file = store, row.names = F)
      message(paste("The file ", paste(output, ".csv", sep = ""), " was saved in ", folder))
      if (length(toPlot) != 0){
      	store <- file.path(folder, paste(output, "_massSpectrum.csv", sep = ""))
      	write.csv(toPlot, file = store, row.names = T)
      	message(paste("The file ", paste(output, "_massSpectrum.csv", sep = ""), " was saved in ", folder))
      }
	} else {
		message("No CSV file was generated as save = FALSE.")
	}
	
	return(list(WholeData, toPlot))
}
