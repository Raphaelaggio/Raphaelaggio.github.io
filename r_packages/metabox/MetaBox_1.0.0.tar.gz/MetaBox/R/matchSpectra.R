matchSpectra <-
function(dataFolder, ionLib, dynamicLibrary = FALSE, scoreCutDynamicLib = 15, saveDynamicLib = FALSE, 
	searchWindow = 0.2, matchFactor = 0.7, correlation = 0.95, scoreCut = 10, noiseThreshold = 0, 
	save = TRUE, output = "MatchReport", peakFindMethod = 2, invertOutput = TRUE, showGraphs = TRUE, saveGraphs = FALSE) {
	################### Check if valid folder ###########################
	validFolder <- function(pathFolder, errorMSG1, errorMSG2, titleMSG1) {
		## Is character? ###
		if (is.character(pathFolder)) {
			isFolder <- file.access(as.character(pathFolder), 0)
			if (isFolder == 0) {
				isFolder <- file.info(pathFolder)
				if (isFolder$isdir == TRUE) {
					pathFolder <- pathFolder
				} else {
					dlgMessage(errorMSG2)
					pathFolder <- dlgDir(title = titleMSG1)$res
				}
			} else {
				dlgMessage(errorMSG2)
				pathFolder <- dlgDir(title = titleMSG1)$res
			}
		} else {
			### If not caharacter ###
			dlgMessage(errorMSG1)
			pathFolder <- dlgDir(title = titleMSG1)$res
		}
		return(pathFolder)
	}
	######################################################################
	title1 <- "Select the folder containing the GC-MS data in CDF format (NetCDF or AIA)."
	error1 <- "The dataFolder is not defined as character. A new window will open allowing you to select a valid folder."
	error2 <- "The dataFolder defined is not a valid folder. A new window will open allowing you to select a valid folder containing the subfolder of each experimental condition with their respective CDF files to be analysed."

	if (missing(dataFolder)) {
		dataFolder <- dlgDir(title = title1)$res
	} else {
		dataFolder <- validFolder(dataFolder, error1, error2, title1)
	}
	### Search subfolders for defining experimental conditions #####
	expConditions <- file.info(list.files(dataFolder, full.names = TRUE))
	expConditions <- expConditions[expConditions$isdir == TRUE, ]
	### If no subfolders found ###
	if (nrow(expConditions) == 0) {
		dlgMessage("The dataFolder specified contains no subfolders defining experimental conditions. We will look for CDF files...")
		findCDF <- list.files(dataFolder, ".cdf", ignore.case = TRUE, full.names = TRUE)
		findCDFNames <- list.files(dataFolder, ".cdf", ignore.case = TRUE, full.names = FALSE)
		if (length(findCDF) == 0) {
			stop("There is no CDF files in the dataFolder specified.")
		}
		message("CDF files found...")
		expConditions <- as.numeric(dlgList(c(1:1000), title = "How many experimental conditions will be analyzed?")$res)
		findCDF <- data.frame(findCDF, stringsAsFactors = FALSE)
		for (i in 1:expConditions) {
			samples <- dlgList(findCDFNames, title = paste("Select the samples belonging to condition", i), multiple = TRUE)$res
			findCDF[which(findCDFNames == samples), 2] <- paste("ExpCond_", i, sep = "")
		}
		replicates <- as.character(findCDF[, 2])
		reps <- factor(replicates)
		expConditions <- nlevels(reps)
		getName <- function(data){
			file <- basename(as.character(data))
			file <- gsub(".CDF", "", file, ignore.case = TRUE)
			return(file)
		}
		findCDF$SampleName <- apply(findCDF[1], 1, function(x) getName(x))
	} else {
		findCDF <- c()
		message("Subfolders representing experimental conditions found...")
		subfolders <- data.frame(basename(row.names(expConditions)), stringsAsFactors = FALSE)
		names(subfolders)[1] <- "ExperimentalConditions"
		pandoc.table(subfolders)
		for (i in 1:nrow(expConditions)) {
			findCDFpre <- list.files(row.names(expConditions[i, ]), ".cdf", ignore.case = TRUE, full.names = TRUE)
			if (length(findCDFpre) == 0) {
				message(paste("The subfolder", basename(row.names(expConditions[i, ])), "contains no CDF files. It will not be considered in this analysis."))
			} else {
				findCDFpre <- data.frame(findCDFpre, stringsAsFactors = FALSE)
				findCDFpre[2] <- basename(row.names(expConditions[i, ]))
				findCDF <- rbind(findCDF, findCDFpre)
			}
		}
		replicates <- as.character(findCDF[, 2])
		reps <- factor(replicates)
		expConditions <- nlevels(reps)
		getName <- function(data){
			file <- basename(as.character(data))
			file <- gsub(".CDF", "", file, ignore.case = TRUE)
			return(file)
		}
		findCDF$SampleName <- apply(findCDF[1], 1, function(x) getName(x))
	}
	
	if (length(findCDF) == 0){
		stop("The subfolders of the folder specified to matchSpectra contain no CDF files. Please organize the CDF files in individual subfolders representing each experimental condition and alocate this set of folders inside of a main folder. The function matchSpectra will then inspect the main folder for subfolders containing CDF files. See ?matchSpectra for more details.")
	}
	######### Check if a CSV or .msl file ############
	isCSVORmsldlg <- function(titleMSG, errorMSG) {
		t = 0
		while (t == 0) {
			checkIfCsv <- dlgOpen(title = titleMSG, multiple = FALSE)$res
			checkIfCsv2 <- basename(checkIfCsv)
			checkIfCsv3 <- unlist(strsplit(checkIfCsv2, "\\."))
			checkIfCsv4 <- checkIfCsv3[length(checkIfCsv3)]
			if (toupper(checkIfCsv4) == "CSV") {
				t = 1
				return(c(checkIfCsv, "csv"))
			} else {
				if (toupper(checkIfCsv4) == "MSL") {
					t = 1
					return(c(checkIfCsv, "msl"))
				} else {
					dlgMessage(errorMSG)
				}
			}
		}
	}
	####################################################
	######### Check if a CSV or .msl file  NO DIALOG BOX ############
isCSVORmsl <- function(pathfile, errorMSG) {
		t = 0
		checkIfCsv2 <- basename(pathfile)
		checkIfCsv3 <- unlist(strsplit(checkIfCsv2, "\\."))
		checkIfCsv4 <- checkIfCsv3[length(checkIfCsv3)]
		if (toupper(checkIfCsv4) == "CSV") {
			t = "csv"
			return(t)
		} else {
			if (toupper(checkIfCsv4) == "MSL") {
				t = "msl"
				return(t)
			} else {
				t = 0
				return(t)
			}
		}
	}
	####################################################  
	##### If no ionLib specified: the user can point to a CSV file or to the .msl file from AMDIS library ####
if (missing(ionLib)) {
		ionLib <- isCSVORmsldlg("Select a CSV file containing the ionLib or the .msl file of the AMDIS library in use.", 
			"The selected file is not a CSV nor a msl file")
		if (ionLib[2] == "csv") {
			ionLibFile <- ionLib[1]
			ionLib = read.csv(ionLib[1], colClass = "character", check.names = FALSE)
			if (ncol(ionLib) != 9) {
				stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
			}
			if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
				message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
				names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
			}
			message("ionLib file loaded...")
		} else {
			ionLibFile <- ionLib[1]
			message("Converting AMDIS library...")
			ionLib <- buildLib(ionLib[1], save = FALSE, verbose = FALSE)
			message("ionLib built and loaded...")
		}
	} else {
		if (is.data.frame(ionLib) == TRUE) {
			if (ncol(ionLib) != 9) {
				stop("The ionLib specified seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
			}
			if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
				message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
				names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
			}
			message("ionLib - Data frame loaded...")
			ionLibFile <- deparse(substitute(ionLib))
		} else {
			if (is.character(ionLib)) {
				checkIfCsv <- isCSVORmsl(ionLib)
				if (checkIfCsv != 0) {
					inputTest <- file.access(ionLib, 0)
					if (inputTest == 0) {
						if (checkIfCsv == "csv") {
							ionLibFile <- ionLib
							ionLib = read.csv(ionLib, colClasses = "character", check.names = FALSE)
							if (ncol(ionLib) != 9) {
								stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
							}
							if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
								message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
								names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
							}
							message("ionLib loaded...")
						} else {
							if (checkIfCsv == "msl") {
								ionLibFile <- ionLib
								message("Converting AMDIS library...")
								ionLib <- buildLib(ionLib, save = FALSE, verbose = FALSE)
								message("ionLib built and loaded...")
							}
						}
					} else {
						dlgMessage("The ionLib specified is not accessible. Please, choose a valid CSV file or msl file to be used as ionLib.")
						ionLib <- isCSVORmsldlg("Select a CSV file containing the ionLib or the .msl file of the AMDIS library in use.", 
							"The selected file is not a CSV nor a msl file")
						if (ionLib[2] == "csv") {
							ionLibFile <- ionLib[1]
							ionLib = read.csv(ionLib[1], colClass = "character", , check.names = FALSE)
							if (ncol(ionLib) != 9) {
								stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
							}
							if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
								message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
								names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
							}
							message("ionLib file loaded...")
						} else {
							if (ionLib[2] == "msl") {
								ionLibFile <- ionLib[1]
								message("Converting AMDIS library...")
								ionLib <- buildLib(ionLib[1], save = FALSE, verbose = FALSE)
								message("ionLib built and loaded...")
							}
						}
					}
				} else {
					dlgMessage("The ionLib specified is not a CSV nor msl file. Please, choose a valid CSV file or msl file to be used as ionLib.")
					ionLib <- isCSVORmsldlg("Select a CSV file containing the ionLib or the .msl file of the AMDIS library in use.", 
						"The selected file is not a CSV nor a msl file")
					if (ionLib[2] == "csv") {
						ionLibFile <- ionLib[1]
						ionLib = read.csv(ionLib[1], colClass = "character", check.names = FALSE)
						if (ncol(ionLib) != 9) {
							stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
						}
						if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
							message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
							names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
						}
						message("ionLib file loaded...")
					} else {
						if (ionLib[2] == "msl") {
							ionLibFile <- ionLib[1]
							message("Converting AMDIS library...")
							ionLib <- buildLib(ionLib[1], save = FALSE, verbose = FALSE)
							message("ionLib built and loaded...")
						}
					}
				}
			} else {
				dlgMessage("The ionLib specified is not a character string nor a data frame. Please, choose a valid CSV file or msl file to be used as ionLib.")
				ionLib <- isCSVORmsldlg("Select a CSV file containing the ionLib or the .msl file of the AMDIS library in use.", 
					"The selected file is not a CSV nor a msl file")
				if (ionLib[2] == "csv") {
					ionLibFile <- ionLib[1]
					ionLib = read.csv(ionLib[1], colClass = "character", check.names = FALSE)
					if (ncol(ionLib) != 9) {
						stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
					}
					if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
						message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
						names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
					}
					message("ionLib file loaded...")
				} else {
					if (ionLib[2] == "msl") {
						ionLibFile <- ionLib[1]
						message("Converting AMDIS library...")
						ionLib <- buildLib(ionLib[1], save = FALSE, verbose = FALSE)
						message("ionLib built and loaded...")
					}
				}
			}
		}
	}

	ionLib[2] <- as.numeric(as.character(ionLib[, 2]))

	######################################
	######### Find Peaks Method 1 ########
######################################
peakFind <- function(x, y) {
		rt <- c()
		iValue <- c()
		for (i in 3:(length(y) - 2)) {
			nextValue <- y[i + 2]
			previousValue <- y[i - 2]
			if (length(nextValue) > 0 && length(previousValue) > 0) {
				if ((previousValue) < y[i] & y[i] > (nextValue)) {
					rt <- c(rt, x[i])
					iValue <- c(iValue, y[i])
				}
			}
		}
		return(data.frame(rt = rt, intensity = iValue, stringsAsFactors = FALSE))
	}
	potentialPeaks <- function(SmoothedCurve, nonSmoothedCurve) {
		peaksFound <- peakFind(as.numeric(as.character(SmoothedCurve[, 1])), as.numeric(as.character(SmoothedCurve[, 
			2])))
		if (nrow(peaksFound) > 0) {
			rtsPeakFound <- round(peaksFound[, 1], 2)
			rtNonSmooth <- round(nonSmoothedCurve[, 1], 2)
			rowsIon <- which(rtNonSmooth %in% rtsPeakFound)
			peaksFound <- nonSmoothedCurve[c(rowsIon), ]
			peaksFound <- peaksFound[!is.na(peaksFound[, 1]), ]
			peaksFound <- peaksFound[!is.na(peaksFound[, 2]), ]
			peaksFound <- peaksFound[peaksFound[, 2] != 0, ]
			return(peaksFound)
		} else {
			peaksFound <- data.frame()
			return(peaksFound)
		}
	}
	######################################
	######### Find Peaks Method 2 ########
######################################
potentialPeaks2 <- function(smoothedData, nonSmoothedData) {
		FindPeaks <- predict(smoothedData, deriv = 1)
		potPeak <- data.frame(set1 = FindPeaks$y > 0)
		potPeak$set2 <- FindPeaks$y[c(2:length(FindPeaks$y), 1)] > 0
		potPeak$peak <- apply(potPeak, 1, function(x) (x[1] == TRUE && x[2] == FALSE))
		PeaksFound <- nonSmoothedData[which(potPeak$peak == TRUE) + 1, ]
		PeaksFound <- PeaksFound[!is.na(PeaksFound[, 1]), ]
		return(PeaksFound)
	}
	#####################################################################################
	##################### Identify compound from library ################################
#####################################################################################
if (showGraphs | saveGraphs){
	initPar <- par()
	dev.off()
}

message("Looking for compounds. Please wait...")
  
findCPD <- function(CDFdata, libRow, peakFindMethod = peakFindMethod, returnOption = returnOption, noiseThreshold = noiseThreshold, dataGC = dataGC) {
		compoundFound <- c()
		imfs <- as.numeric(libRow[1,3:6])
		RTTarget <- c(as.numeric(libRow[1, 2]) - searchWindow, as.numeric(libRow[1, 2]) + searchWindow) 	
		ionFinalT <- lapply(as.list(imfs), function(x) extract_ion(CDFdata, as.numeric(x), RTTarget))	
		ionFinalTframe <- as.data.frame(ionFinalT, stringsAsFactors = FALSE)
		ionFinalTframe <- ionFinalTframe[c(1,2,4,6,8)]
		nasFound <- apply(ionFinalTframe, 1, function(x) sum(is.na(x)))
		nasFound <- which(nasFound == 5)
		if (length(nasFound) > 0){
			ionFinalT <- lapply(ionFinalT, function(x) x[-nasFound,])
			ionFinalTframe <- ionFinalTframe[-nasFound,]
		}
		if (nrow(ionFinalTframe) > 0){
			###### Plot graph ########
			if (showGraphs == FALSE && saveGraphs){
				folderPath <- file.path(dataFolder, "MetaBoxGraphOutput")
				isFolder <- file.access(as.character(folderPath), 0)
				if (isFolder == 0) {
					isFolder <- file.info(folderPath)
					if (isFolder$isdir) {
						#do nothing
					} else {
						dir.create(folderPath)
					}
				} else {
					dir.create(folderPath)
				}
				name.file <- basename(dataGC)
				name.file <- gsub(".cdf", paste("_", libRow[1, 1], ".pdf", sep = ""), name.file, fixed = FALSE, ignore.case = TRUE)
				graphNameChrom <- file.path(folderPath, name.file)
				pdf(graphNameChrom)
				suppressWarnings(par(initPar))
				toPlot <- which(round(CDFdata@scantime) %in% round(ionFinalTframe[, 1] * 60))
				plot(CDFdata@scantime[toPlot]/60, CDFdata@tic[toPlot], xlab = "RT(min)", ylab = "Intensity", main = paste("Searching for ", libRow[1, 1], " in ", basename(dataGC), sep = ""), col = "grey", type = "l", ylim = c(-50, max(CDFdata@tic[toPlot], na.rm = TRUE)), cex.main = 0.7, bty = "n", cex.axis = 0.6, las = 1)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 2], type = "l", col = "firebrick3"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 3], type = "l", col = "dodgerblue4"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 4], type = "l", col = "forestgreen"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 5], type = "l", col = "goldenrod3"), TRUE)
				try(legend("topleft", legend = c("TIC", libRow[1, c(3:6)]), cex = 0.5, col = c("grey", "firebrick3", "dodgerblue4", "forestgreen", "goldenrod3"), lty = c(1, 1, 1, 1, 1), title = "Fragments", lwd = 3, merge = FALSE, bty = "n"), TRUE)
			}	
			if (showGraphs){
				suppressWarnings(par(initPar))
				toPlot <- which(round(CDFdata@scantime) %in% round(ionFinalTframe[, 1] * 60))
				plot(CDFdata@scantime[toPlot]/60, CDFdata@tic[toPlot], xlab = "RT(min)", ylab = "Intensity", main = paste("Searching for ", libRow[1, 1], " in ", basename(dataGC), sep = ""), col = "grey", type = "l", ylim = c(-50, max(CDFdata@tic[toPlot], na.rm = TRUE)), cex.main = 0.7, bty = "n", cex.axis = 0.6, las = 1)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 2], type = "l", col = "firebrick3"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 3], type = "l", col = "dodgerblue4"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 4], type = "l", col = "forestgreen"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 5], type = "l", col = "goldenrod3"), TRUE)
				try(legend("topleft", legend = c("TIC", libRow[1, c(3:6)]), cex = 0.5, col = c("grey", "firebrick3", "dodgerblue4", "forestgreen", "goldenrod3"), lty = c(1, 1, 1, 1, 1), title = "Fragments", lwd = 3, merge = FALSE, bty = "n"), TRUE)
			}
			##########################	
			###############################################################
			### At least 3 ions of the spectral library must be present ###
			###############################################################
			noIMFS <- apply(ionFinalTframe[-1], 1, function(x) sum(x == 0))
			noIMFS <- which(noIMFS >= 2)
			if (length(noIMFS) > 0){
				ionFinalT <- lapply(ionFinalT, function(x) x[-noIMFS,])
				ionFinalTframe <- ionFinalTframe[-noIMFS,]
			}
			if (nrow(ionFinalTframe) != 0){	
				# Data sets: ionFinalT as list/ ionFinalTframe as data frame
				# Peaks: peaksFound1 = row number / peaksFound2 = RT / rtsPeakFound = data frame with all the peaks of all 4 IMFs analysed.
				if (peakFindMethod == 1) {
					ionFinal <- lapply(ionFinalT, function(x) spline(x[, 1], x[, 2], method = "fmm"))
					ionFinal <- as.data.frame(ionFinal, stringsAsFactors = FALSE)
					ionFinal <- ionFinal[c(1,2,4,6,8)]
					ionFinal <- apply(ionFinal[-1], 2, function(x) peakFind(ionFinal[, 1], x))
					peaksFound <- lapply(ionFinal, function(x) x$rt)		
					if (length(peaksFound[[1]]) > 0) {
						nPeaks <- lapply(peaksFound, function(x) length(x))
						nPeaks <- which(nPeaks > 0)
						peaksFound <- peaksFound[nPeaks]
						peaksFound <- lapply(peaksFound, function(x) round(x, 2))
						rtNonSmooth <- round(ionFinalTframe[, 1], 2)
						peaksFound1 <- lapply(peaksFound, function(x) which(rtNonSmooth %in% x))
						peaksFound2 <- lapply(peaksFound1, function(x) rtNonSmooth[x])
						rtsPeakFound <- as.numeric(unlist(peaksFound1))
						rtsPeakFound <- rtsPeakFound[!duplicated(rtsPeakFound)]
						rtsPeakFound <- rtsPeakFound[order(rtsPeakFound)]
						rtsPeakFound <- ionFinalTframe[as.numeric(rtsPeakFound),]	
					} else {
						rtsPeakFound <- data.frame()
					}				
				}	
				if (peakFindMethod == 2) {
					ionFinal <- lapply(ionFinalT, function(x) smooth.spline(x[, 1], x[, 2]))
					ionFinal <- lapply(ionFinal, function(x) predict(x, deriv = 1))
					SearchForPeaks <- function(data){
						potPeak <- data.frame(set1 = data$y > 0)
						potPeak$set2 <- data$y[c(2:length(data$y), 1)] > 0
						potPeak$peak <- apply(potPeak, 1, function(x) (x[1] == TRUE && x[2] == FALSE))
						peaksFound <- c(which(potPeak$peak == TRUE))
						peaksFound <- round(data$x[peaksFound],2)
						return(peaksFound)
					}
					peaksFound <- lapply(ionFinal, function(x) SearchForPeaks(x))
					rtNonSmooth <- round(ionFinalTframe[, 1], 2)
					peaksFound1 <- lapply(peaksFound, function(x) which(rtNonSmooth %in% x))
					peaksFound2 <- lapply(peaksFound1, function(x) rtNonSmooth[x])			
					rtsPeakFound <- as.numeric(unlist(peaksFound1))
					rtsPeakFound <- rtsPeakFound[!duplicated(rtsPeakFound)]
					rtsPeakFound <- rtsPeakFound[order(rtsPeakFound)]
					rtsPeakFound <- ionFinalTframe[as.numeric(rtsPeakFound),]
				}	
				if (peakFindMethod == 3) {
					ionFinal <- lapply(ionFinalT, function(x) spline(x[, 1], x[, 2], method = "fmm"))
					SearchForPeaks2 <- function(data){
						dataSizeWave <- data.frame(Size = c(16,rep(32,2),rep(64,4), rep(128,8), rep(256,16), rep(512,32), 1024), wavelimit = c(1:64), stringsAsFactors = FALSE)
						dataToWave <- as.numeric(data$y)
						if (sum(dataToWave == 0) == length(dataToWave)){
							peaksFound <- 0
						} else {	
							waveLimit <- which(dataSizeWave[,1] <= length(dataToWave))	
							scales <- dataSizeWave[waveLimit, 2]
							wCoefs <- cwt(dataToWave, scales = scales, wavelet = "mexh")	
							wCoefs <- cbind(dataToWave, wCoefs)	
							colnames(wCoefs) <- c(0,scales)	
							localMax <- getLocalMaximumCWT(wCoefs)
							ridgeList <- getRidge(localMax)
							majorPeakInfo <- identifyMajorPeaks(dataToWave, ridgeList, wCoefs, SNR.Th = 3, nearbyPeak = TRUE)
							peaksFound <- majorPeakInfo$potentialPeakIndex
							peaksFound <- round(data$x[peaksFound], 2)
						}
						return(peaksFound)
					}
					peaksFound <- lapply(ionFinal, function(x) SearchForPeaks2(x))
					rtNonSmooth <- round(ionFinalTframe[, 1], 2)
					peaksFound1 <- lapply(peaksFound, function(x) which(rtNonSmooth %in% x))
					peaksFound2 <- lapply(peaksFound1, function(x) rtNonSmooth[x])			
					rtsPeakFound <- as.numeric(unlist(peaksFound1))
					rtsPeakFound <- rtsPeakFound[!duplicated(rtsPeakFound)]
					rtsPeakFound <- rtsPeakFound[order(rtsPeakFound)]
					rtsPeakFound <- ionFinalTframe[as.numeric(rtsPeakFound),]
				}
				if(nrow(rtsPeakFound) > 0){		
					for (i in 2:5){
						rtsPeakFound[rtsPeakFound[,i] < noiseThreshold, i] <- NA
					}		
					rowsToRemove <- apply(rtsPeakFound[2:5], 1, function(x) sum(is.na(x)))
					rowsToRemove <- which(rowsToRemove > 1)
					if (length(rowsToRemove) > 0){
						rtsPeakFound <- rtsPeakFound[-rowsToRemove,]
					}
					if(nrow(rtsPeakFound) > 0){
						######################		
						####### Stage 2 ######
						######################
						getRatioSimilarity <- function(x, theoryRatio){
							observedRatio <- x[2]/x[1]
							if (is.na(theoryRatio) | is.na(observedRatio)){
								ratio <- 0
							} else {
								ratio <- min(c(theoryRatio, observedRatio), na.rm = TRUE)/max(c(theoryRatio, observedRatio), na.rm = TRUE)
							}
							if (is.na(ratio)){
								ratio <- 0
							}
							return(ratio)
						}
						ratio1 <- apply(rtsPeakFound[c(2,3)], 1, function(x) getRatioSimilarity(x, as.numeric(libRow$R2[1])))
						ratio2 <- apply(rtsPeakFound[c(2,4)], 1, function(x) getRatioSimilarity(x, as.numeric(libRow$R3[1])))
						ratio3 <- apply(rtsPeakFound[c(2,5)], 1, function(x) getRatioSimilarity(x, as.numeric(libRow$R4[1])))				
						rtsPeakFound$Score <- unlist(lapply(ratio1, function(x) sum(x >= matchFactor)))
						rtsPeakFound$Score <- rtsPeakFound$Score + unlist(lapply(ratio2, function(x) sum(x >= matchFactor)))
						rtsPeakFound$Score <- rtsPeakFound$Score + unlist(lapply(ratio3, function(x) sum(x >= matchFactor)))
						rtsPeakFound <- rtsPeakFound[rtsPeakFound$Score > 0,]				
						if (nrow(rtsPeakFound) > 0){
							ionFinalTframe <- ionFinalTframe[ionFinalTframe[,1] %in% rtsPeakFound[,1],]
							######################		
							####### Stage 1 ######
							######################
							ScoreStage1 <- function(data, peaksFound2, ionFinalTframe){
								dataRT <- round(data[1], 2)
								Score1 <- sum(unlist(lapply(peaksFound2, function(x) sum(dataRT %in% x))))
								Score2 <- sum(data[2:5] != 0, na.rm = TRUE)
								MaxValues <- apply(ionFinalTframe[2:5], 2, function(x) round(x[which(x == suppressWarnings(max(x, na.rm = TRUE)))], 2))
								MaxValues <- lapply(MaxValues, function(x) x = x[!duplicated(x)])
								Score3 <- sum(data[2:5] == MaxValues, na.rm = TRUE)
								Score <- Score1 + Score2 + Score3
								return(Score)	
							}
							rtsPeakFound$Score <- rtsPeakFound$Score + apply(rtsPeakFound, 1, function(x) ScoreStage1(x, peaksFound2, ionFinalTframe))		
							######################		
							####### Stage 3 ######
							######################
							getScoreCorrelation <- function(data, imfs){
								data <- round(data[1], 2)
								RTTarget <- c(data - 0.07, data + 0.07) 
								AllIons <- lapply(as.list(imfs), function(x) extract_ion(CDFdata, as.numeric(x), RTTarget))
								AllIonsFrame <- as.data.frame(AllIons, stringsAsFactors = FALSE)
								AllIonsFrame <- AllIonsFrame[c(2,4,6,8)]
								Correlation <- apply(AllIonsFrame[-1], 2, function(x) suppressWarnings(cor(x, AllIonsFrame[1])))
								Correlation[is.na(Correlation)] <- 0
								return(Correlation)
							}
							rtsPeakFound$Score <- rtsPeakFound$Score + unlist(apply(rtsPeakFound[1], 1, function(x) sum(getScoreCorrelation(x, imfs) >= correlation)))
							ionFinalTframe <- ionFinalTframe[ionFinalTframe[,1] %in% rtsPeakFound[,1],]					
							if (showGraphs | saveGraphs){
								try(text(ionFinalTframe[, 1], ionFinalTframe[, 2], labels = rtsPeakFound$Score, cex = 0.5, col = "grey"), TRUE)
							}
							#####################################
							### Select RT with the best Score ###
							#####################################
							rtsPeakFound <- rtsPeakFound[which(rtsPeakFound$Score == suppressWarnings(max(rtsPeakFound$Score, na.rm = TRUE))) ,]				
							###########################################################
							### Calculate the diff between observed and expected RT ###
							###########################################################
							rtsPeakFound$RTDiff <- unlist(apply(rtsPeakFound[1], 1, function(x) abs(as.numeric(x) - as.numeric(libRow[1,2]))))
							if (nrow(rtsPeakFound) > 1){	
								rtsPeakFound <- rtsPeakFound[rtsPeakFound $RTDiff == min(rtsPeakFound$RTDiff, na.rm = TRUE), ]
							}			
							ionFinalTframe <- ionFinalTframe[ionFinalTframe[,1] %in% rtsPeakFound[1,1],]					
												
							############ Add compound name to graph #######
							if (showGraphs | saveGraphs){
								maxIon <- max(ionFinalTframe[1, 2], na.rm = TRUE)
								if (maxIon < (max(CDFdata@tic[toPlot], na.rm = TRUE)/2)) {
									distSeg2 <- max(CDFdata@tic[toPlot], na.rm = TRUE)/6
								} else {
									distSeg2 <- maxIon/10
								}
								try(segments(ionFinalTframe[1, 1], ionFinalTframe[1, 2], ionFinalTframe[1, 1], (ionFinalTframe[1, 2] + (distSeg2)), col = "red", lty = 3), TRUE)
								try(text(ionFinalTframe[1, 1], (ionFinalTframe[1, 2] + (distSeg2 * 1.1)), labels = paste(as.character(libRow[1, 1]), "[", ionFinalTframe[1, 1], "]", sep = " "), cex = 0.35), TRUE)					
								############# Add bar graph to figure ######					
								par(fig = c(0.6, 1, 0.5, 0.95), mar = c(5, 5, 2, 1), new = T, xpd = T)
								dataToPlot <- t(cbind(c(1, libRow[1, 7], libRow[1, 8], libRow[1, 9]), c(1, ionFinalTframe[1, 3]/ionFinalTframe[1, 2], ionFinalTframe[1, 4]/ionFinalTframe[1, 2], ionFinalTframe[1, 5]/ionFinalTframe[1, 2])))
								dataToPlot[dataToPlot > 1] <- 1
								try(barplot(as.numeric(dataToPlot), col = c("black", "firebrick3", "black", "dodgerblue4", "black", "forestgreen", "black", "goldenrod3"), beside = TRUE, cex.axis = 0.3, cex.main = 0.5, border = NA, main = "Spectra match"), TRUE)
								points(2.05, -0.1, pch = 15)
								text(2.05, -0.1, "Expected intensity", cex = 0.6, pos = 4)
							}
							if (showGraphs && saveGraphs) {
								folderPath <- file.path(dataFolder, "MetaBoxGraphOutput")
								isFolder <- file.access(as.character(folderPath), 0)
								if (isFolder == 0) {
									isFolder <- file.info(folderPath)
									if (isFolder$isdir) {
										#do nothing
									} else {
										dir.create(folderPath)
									}
								} else {
									dir.create(folderPath)
								}
								name.file <- basename(dataGC)
								name.file <- gsub(".cdf", paste("_", libRow[1, 1], ".pdf", sep = ""), name.file, fixed = FALSE, ignore.case = TRUE)
								graphNameChrom <- file.path(folderPath, name.file)
								dev.copy2pdf(file = graphNameChrom)
							}
							if (showGraphs == FALSE && saveGraphs == TRUE){
								dev.off()
							}
							compoundFound <- data.frame(Name = libRow[1, 1], RetTime = as.numeric(rtsPeakFound[1, 1]), diffTime = round(as.numeric(rtsPeakFound$RTDiff), 3), Score = as.numeric(rtsPeakFound$Score), Intensity = as.numeric(rtsPeakFound[1, 2]), stringsAsFactors = FALSE)
							if (returnOption == 1){
								compoundFound2 <- data.frame(c(libRow[1, 1], rtsPeakFound[1,]), stringsAsFactors = FALSE)
								names(compoundFound2) <- c("Name", "RetTime", "Ion1", "Ion2", "Ion3", "Ion4", "Score", "RTDiff")
								return(compoundFound2)
							} else {
								return(compoundFound)
							}
						} else {
							if (showGraphs == FALSE && saveGraphs == TRUE){
								dev.off()
							}
						}
					} else {
						if (showGraphs == FALSE && saveGraphs == TRUE){
							dev.off()
						}
					}	
				} else {
					if (showGraphs == FALSE && saveGraphs == TRUE){
						dev.off()
					}
				}
			} else {
				if (showGraphs == FALSE && saveGraphs == TRUE){
					dev.off()
				}
			}
		}
	}
    #############################################################################
	######### Check if there is any peak for each compound in the library #######
	#############################################################################
	IdentfyCPDSingle <- function(data, ionLib, peakFindMethod, returnOption, noiseThreshold, dataGC){
		preReport <- apply(ionLib, 1, function(x) findCPD(data, data.frame(t(x), stringsAsFactors = FALSE), returnOption = returnOption, peakFindMethod = peakFindMethod, noiseThreshold = noiseThreshold, dataGC = dataGC))
		preReport <- do.call(rbind, preReport)
		### Remove duplicated compounds per RT ###
		preReport <- preReport[!duplicated(preReport), ]
		dupli <- preReport[duplicated(preReport[2]), ]
		dupliRT <- dupli[, 2]
		dupliRT <- dupliRT[!duplicated(dupliRT)]
		if (length(dupliRT) > 0) {
			for (d in 1:length(dupliRT)) {
				toDecide <- preReport[preReport[2] == dupliRT[d], ]
				toDelete <- row.names(toDecide)
				toDecide <- toDecide[toDecide$Score == suppressWarnings(max(toDecide$Score, na.rm = TRUE)), ]
				if (nrow(toDecide) > 1) {
					toDecide <- toDecide[toDecide$diffTime == min(toDecide$diffTime, na.rm = TRUE), ]
				}
				if (nrow(toDecide) > 1) {
					toDecide <- toDecide[1, ]
				}
				deleteComp <- which(toDelete != row.names(toDecide))
				preReport <- preReport[-c(which(row.names(preReport) %in% toDelete[deleteComp])), ]
			}
		}
		return(preReport)
	}
	
	###############################################################################################
	######### Load the data and check if there is any peak for each compound in the library #######
	###############################################################################################
	IdentfyCPD <- function(dataGC, ionLib, peakFindMethod = peakFindMethod, returnOption = returnOption, noiseThreshold = noiseThreshold, ...){
		data <- xcmsRaw(dataGC)
		Results <- IdentfyCPDSingle(data, ionLib, peakFindMethod = peakFindMethod, returnOption = returnOption, noiseThreshold = noiseThreshold, dataGC = dataGC)
		return(Results)
	}		
	#####################################
	#### If dynamic library = TRUE ######
	#####################################
	if (dynamicLibrary == TRUE) {
		finalData <- apply(findCDF[1], 1, function(x) IdentfyCPD(x, ionLib, peakFindMethod = peakFindMethod, returnOption = 1, noiseThreshold = noiseThreshold, dataFolder = dataFolder, saveGraphs = FALSE, showGraphs = FALSE))		
		########################################
		######### Generate cutoff report #######
		########################################
		finalDataLib <- lapply(finalData, function(x) x[x$Score >= scoreCutDynamicLib,])
		finalDataLib <- do.call('rbind', lapply(1:length(finalDataLib), function(x){cbind(finalDataLib[[x]], q=x)}))
		#####################################
		######### Build the new Library #####
		#####################################
		duplicatedComps <- finalDataLib[duplicated(finalDataLib[, 1]), ]
		duplicatedComps <- duplicatedComps[!duplicated(duplicatedComps[, 1]), ]
		if (nrow(duplicatedComps) > 0) {
			ionLib$ERT <- as.numeric(as.character(ionLib$ERT))
			for (dupli in 1:nrow(duplicatedComps)) {
				compRows <- finalDataLib[finalDataLib[, 1] == duplicatedComps[dupli, 1], ]
				originalRow <- which(ionLib[, 1] == duplicatedComps[dupli, 1])
				ionLib$ERT[originalRow] <- round(mean(compRows$RetTime, na.rm = TRUE), 3)
				ionLib$R2[originalRow] <- round(mean(apply(compRows, 1, function(x) as.numeric(x[4])/as.numeric(x[3])), na.rm = TRUE), 3)
				ionLib$R3[originalRow] <- round(mean(apply(compRows, 1, function(x) as.numeric(x[5])/as.numeric(x[3])), na.rm = TRUE), 3)
				ionLib$R4[originalRow] <- round(mean(apply(compRows, 1, function(x) as.numeric(x[6])/as.numeric(x[3])), na.rm = TRUE), 3)
			}
		}
		if (saveDynamicLib == TRUE) {
			FileName <- "DynamicLib"
			dateForFile <- Sys.time()
			dateForFile <- gsub(" ", "", dateForFile)
			dateForFile <- gsub(":", "", dateForFile)
			userName <- Sys.info()
			userName <- userName[[7]]
			FileName <- paste(FileName, dateForFile, userName, ".csv", sep = "_")
			placeToSave <- file.path(dataFolder, FileName)
			write.csv(ionLib, file = placeToSave, row.names = FALSE)
			message(paste("The new ion library was saved into: ", placeToSave, sep = ""))
		}
	}
	####################################################################################################################
	######### For each GC-MS file, load the data and check if there is any peak for each compound in the library #######
	####################################################################################################################	
	finalData <- apply(findCDF[1], 1, function(x) IdentfyCPD(x, ionLib, peakFindMethod = peakFindMethod, returnOption = 2, noiseThreshold = noiseThreshold, dataFolder = dataFolder, saveGraphs = saveGraphs, showGraphs = showGraphs))

	#######################################
	######### Generate total report #######
	#######################################
	finalDataBig <- do.call('rbind', lapply(1:length(finalData), function(x){cbind(finalData[[x]], q=x)}))
	finalDataBig <- reshape(finalDataBig, idvar='Name', timevar='q', direction='wide')
	namesToAdd <- function(sampleName){
		valueToAdd <- c("RT_", "DiffRT_", "Score_")
		sampleName <- c(paste(valueToAdd, sampleName, sep = ""), sampleName)
		return(sampleName)
	}
	names(finalDataBig)[2:ncol(finalDataBig)] <- unlist(apply(findCDF[3], 1, function(x) namesToAdd(x)))

	########################################
	######### Generate cutoff report #######
	########################################
	finalDataSmall <- lapply(finalData, function(x) x[x$Score >= scoreCut,])
	finalDataSmall <- lapply(finalDataSmall, function(x) x[c(1,5)])
	finalDataSmall <- do.call('rbind', lapply(1:length(finalDataSmall), function(x){cbind(finalDataSmall[[x]], q=x)}))
	finalDataSmall <- reshape(finalDataSmall, idvar='Name', timevar='q', direction='wide')
	names(finalDataSmall)[2:ncol(finalDataSmall)] <- findCDF[,3]
	
	####################################
	######### Add row Replicates #######
	####################################
	rep.name.final <- c("Replicates", rep(replicates, 1, each = 4))
	finalDataBig[1] <- as.character(finalDataBig[, 1])
	finalDataBig <- rbind(rep.name.final, finalDataBig)
	
	rep.name.final <- c("Replicates", replicates)
	finalDataSmall[1] <- as.character(finalDataSmall[, 1])
	finalDataSmall <- rbind(rep.name.final, finalDataSmall)
	
	if(invertOutput){
		finalDataBig <- data.frame(t(finalDataBig), stringsAsFactors = FALSE, check.names = FALSE)
		names(finalDataBig) <- finalDataBig[1,]
		finalDataBig <- finalDataBig[-1,]
		
		finalDataSmall <- data.frame(t(finalDataSmall), stringsAsFactors = FALSE, check.names = FALSE)
		names(finalDataSmall) <- finalDataSmall[1,]
		finalDataSmall <- finalDataSmall[-1,]
	}
	logFile <- data.frame(DataFolder = dataFolder, File = "none", SearchWindow = searchWindow, MatchFactor = matchFactor, Correlation = correlation, ScoreCut = scoreCut, Library = ionLibFile, DynamicLibrary = dynamicLibrary, ScoreCutDynamicLibrary = scoreCutDynamicLib, NoiseThreshold = noiseThreshold, PeakFindMethod = peakFindMethod, stringsAsFactors = FALSE)
	if (save == TRUE) {
		sheet <- output
		store <- file.path(dataFolder, paste(sheet, "Total.csv", sep = ""))
		inputTest <- file.access(store, 0)
		if (inputTest == 0){
			addFile <- 1
			while(inputTest == 0){
				store <- file.path(dataFolder, paste(sheet, "Total", addFile, ".csv", sep = ""))
				inputTest <- file.access(store, 0)
				addFile <- addFile + 1
			}
		}
		if(invertOutput){
			write.csv(finalDataBig, file = store, row.names = TRUE)
		} else {
			write.csv(finalDataBig, file = store, row.names = FALSE)
		}
		bidGata <- store
		sheet <- output
		store <- file.path(dataFolder, paste(sheet, "CutOff.csv", sep = ""))
		inputTest <- file.access(store, 0)
		if (inputTest == 0){
			addFile <- 1
			while(inputTest == 0){
				store <- file.path(dataFolder, paste(sheet, "CutOff", addFile, ".csv", sep = ""))
				inputTest <- file.access(store, 0)
				addFile <- addFile + 1
			}
		}
		if(invertOutput){
			write.csv(finalDataSmall, file = store, row.names = TRUE)
		} else {
			write.csv(finalDataSmall, file = store, row.names = FALSE)
		}
		smallData <- store
		sheet <- paste("logFile", output, sep = "_")
		store <- file.path(dataFolder, paste(sheet, ".csv", sep = ""))
		inputTest <- file.access(store, 0)
		if (inputTest == 0){
			addFile <- 1
			while(inputTest == 0){
				store <- file.path(dataFolder, paste(sheet, addFile, ".csv", sep = ""))
				inputTest <- file.access(store, 0)
				addFile <- addFile + 1
			}
		}
		write.csv(logFile, file = store, row.names = FALSE)
		logData <- store
		message("Done!")
		message(paste("The following files were saved in ", dataFolder, ":", sep = ""))
		pandoc.table(data.frame(OutputFiles = c(bidGata, smallData, logData), stringsAsFactors = FALSE))
	} else {
		message("No file was saved because the argument save was set as FALSE")
	}
	Report <- list(finalDataBig, finalDataSmall, ionLib, logFile)
	names(Report) <- c("Total", "cutOff", "ionLib", "logFile")
	return(Report)
}
