findNoise <- function(data, folder, name.file = "findNoiseGraph", saveGraph = FALSE, limitScan, plotGraph = TRUE) {

	if (missing(data)) {
		stop("The argument data is missing.")
	}
	#####################################
	##### Set folder if SAVE == TRUE ####
#####################################
if (saveGraph) {
		if (missing(folder)) {
			folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
		} else {
			if (is.character(folder)) {
				isFolder <- file.access(as.character(folder), 0)
				if (isFolder == 0) {
					isFolder <- file.info(folder)
					if (isFolder$isdir != TRUE) {
						message("The folder defined to save the results is not a valid path. Please, point to the folder where the results should be saved.")
						folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
					}
				} else {
					message("The folder defined to save the results is not a valid path. Please, point to the folder where the results should be saved.")
					folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
				}
			} else {
				message("The path to the folder where the results will be saved must be specified as character. Please, point to the folder where the results should be saved.")
				folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
			}
		}
	}

	noiseSample <- data.frame()
	##############################################
	############ Get the data to plot ############
##############################################
toPlot <- data.frame(RT = data@scantime/60, Intensity = data@tic, stringsAsFactors = FALSE)
	##############################################
	###### Only plot if plotGraph = TRUE #########
##############################################
if (plotGraph) {
		plotFlatArea <- try(plot(toPlot, type = "l", main = "Point used for noise subtraction", cex.main = 0.7, bty = "n", 
			ylab = "Intensity", xlab = "RT(min)"), TRUE)
	}
	toPlot2 <- data.frame(RT = c(1:length(data@scantime)), Intensity = data@tic, stringsAsFactors = FALSE)
	toPlot2 <- toPlot2[toPlot2[, 2] > 0, ]

	##############################################
	#################### Check limitScan #########
##############################################
if (missing(limitScan)) {
		i <- 1
		rtFinal <- 13
		while (i <= nrow(toPlot2) && rtFinal <= nrow(toPlot2)) {
			dataNoise <- toPlot2[c(i:rtFinal), ]
			meanScans <- mean(dataNoise[, 2], na.rm = TRUE)
			dataNoise$lower <- dataNoise[2] < meanScans
			dataNoise$lower2 <- dataNoise[c(2:13, 1), 3]
			dataNoise$lower3 <- apply(dataNoise[c(3, 4)], 1, function(x) x[1] == x[2])
			crossings <- sum(dataNoise[, 5] == FALSE)
			if (crossings <= 6) {
				i <- rtFinal + 1
				rtFinal <- i + 12
			} else {
				noiseSample <- rbind(noiseSample, dataNoise[which(dataNoise[, 2] == min(dataNoise[, 2], na.rm = TRUE)), c(1:2)])
				i <- rtFinal + 1
				rtFinal <- i + 12
			}
		}
	} else {
		i <- 1
		rtFinal <- 13
		while (i <= nrow(toPlot2) && rtFinal <= nrow(toPlot2) && rtFinal < limitScan) {
			dataNoise <- toPlot2[c(i:rtFinal), ]
			meanScans <- mean(dataNoise[, 2], na.rm = TRUE)
			dataNoise$lower <- dataNoise[2] < meanScans
			dataNoise$lower2 <- dataNoise[c(2:13, 1), 3]
			dataNoise$lower3 <- apply(dataNoise[c(3, 4)], 1, function(x) x[1] == x[2])
			crossings <- sum(dataNoise[, 5] == FALSE)
			if (crossings <= 6) {
				i <- rtFinal + 1
				rtFinal <- i + 12
			} else {
				noiseSample <- rbind(noiseSample, dataNoise[which(dataNoise[, 2] == min(dataNoise[, 2], na.rm = TRUE)), c(1:2)])
				i <- rtFinal + 1
				rtFinal <- i + 12
			}
		}
	}

	##############################################
	################# If noise was found #########
##############################################
if (nrow(noiseSample) > 0) {
		if (plotGraph) {
			if ("try-error" %in% class(plotFlatArea)) {
				# Do nothing
				} else {
				noiseSample <- noiseSample[which(noiseSample[, 2] == min(noiseSample[, 2], na.rm = TRUE)), ]
				finalNoise <- toPlot[as.numeric(noiseSample[1, 1]), ]
				try(points(as.matrix(finalNoise), col = "red", pch = 19), TRUE)
				try(segments(finalNoise[1, 1], finalNoise[1, 2], finalNoise[1, 1], max(data@tic)/2, col = "red", lwd = 2), TRUE)
				try(text(finalNoise[1, 1], (max(data@tic)/2) + (max(data@tic)/12), "Noise subtraction point", cex = 0.7), TRUE)
			}
		} else {
			noiseSample <- noiseSample[which(noiseSample[, 2] == min(noiseSample[, 2], na.rm = TRUE)), ]
		}
		if (plotGraph && saveGraph) {
			graphName <- file.path(folder, paste(name.file, ".pdf", sep = ""))
			dev.copy2pdf(file = graphName)
		}
		scanValue <- getScan(data, as.numeric(noiseSample[1, 1]))
		scanValue <- scanValue[scanValue[, 2] != 0, ]
		scanValue <- data.frame(scanValue)
		return(scanValue)
	} else {
		message("No flat area was found for noise subtraction.")
		scanValue <- c()
		return(scanValue)
	}
}
