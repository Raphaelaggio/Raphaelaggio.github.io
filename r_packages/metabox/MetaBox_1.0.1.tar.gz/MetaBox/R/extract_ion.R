extract_ion <-
function(data, mz = 43, timeWindow = c(10.2, 11), by = 0.01) {
	##############################################
	######### Get intensities ####################
	##############################################
	getIntensities <- function(sample, scan, mz) {
		feed <- getScan(sample, scan)
		intensityOf <- data.frame(round(feed))
		intensityOf <- intensityOf[intensityOf[, 1] == mz, ]
		if (nrow(intensityOf) > 0) {
			listOfint <- max(intensityOf[2], na.rm = TRUE)
		} else {
			listOfint <- 0
		}
		if(is.infinite(listOfint)){
			listOfint <- 0
		}
		return(listOfint)
	}
	sample <- data
	timeRange <- sample@scantime
	timeRange <- round(timeRange)
	select <- timeRange[timeRange %in% seq(round(timeWindow[1] * 60), 
		round(timeWindow[2] * 60), by)]
	beggin <- which(timeRange == select[1])
	beggin <- beggin[1]
	finish <- which(timeRange == select[length(select)])
	finish <- finish[length(finish)]
	if (length(beggin) > 0 & length(finish) > 0) {
		listOf <- sapply(c(beggin:finish), function(x) getIntensities(sample, x, mz))
		rt <- sample@scantime[beggin:finish]/60
		listOf <- cbind(rt, intensity = as.numeric(listOf))
		listOf <- data.frame(listOf)
		roundFactor <- 5
		listOf2 <- listOf
		anyDuplicated <- duplicated(round(listOf2[, 1], roundFactor))
		if (length(which(anyDuplicated == TRUE)) > 0) {
			while (length(which(anyDuplicated == TRUE)) > 0) {
				roundFactor <- roundFactor + 1
				listOf2 <- data.frame(RT = listOf)
				anyDuplicated <- duplicated(round(listOf2[, 1], roundFactor))
			}
		}
		listOf[1] <- round(listOf[, 1], roundFactor)
		names(listOf) <- c("rt", mz)
		return(listOf)
	} else {
		return(data.frame(rt = NA, RT.intensity = NA))
	}
}
