filterCDF <-
function(data, filterNoise = TRUE, mzListToFilter = c(1:30), save = TRUE, folder, output = "_noNoise", 
	limitScan, plotGraph = TRUE) {

	######### Check if a .CDF file ###########################
	isCDFdlg <- function(titleMSG, errorMSG) {
		t = 0
		while (t == 0) {
			checkIfCDF <- dlgOpen(title = titleMSG, multiple = FALSE)$res
			checkIfCDF2 <- basename(checkIfCDF)
			checkIfCDF3 <- unlist(strsplit(checkIfCDF2, "\\."))
			checkIfCDF4 <- checkIfCDF3[length(checkIfCDF3)]
			if (toupper(checkIfCDF4) == "CDF") {
				t = 1
				return(checkIfCDF)
			} else {
				dlgMessage(errorMSG)
			}
		}
	}

	######### Check if a .CDF file  NO DIALOG BOX ############
	isCDF <- function(pathfile, errorMSG) {
		t = 0
		checkIfCDF2 <- basename(pathfile)
		checkIfCDF3 <- unlist(strsplit(checkIfCDF2, "\\."))
		checkIfCDF4 <- checkIfCDF3[length(checkIfCDF3)]
		if (toupper(checkIfCDF4) == "CDF") {
			t = 1
			return(t)
		} else {
			t = 0
			return(t)
		}
	}


	############## Load CDF file ############################
	if (missing(data)) {
		data <- isCDFdlg("Select the .CDF file to be filtered.", "The selected file is not a CDF file")
		raw_data <- xcmsRaw(data)
		sourceFile <- "data"
	} else {
		isGCdata <- class(data)
		if (isGCdata[1] == "xcmsRaw") {
			raw_data <- data
			sourceFile <- "xcmsRaw"
		} else {
			if (is.character(data)) {
				checkIfCDF <- isCDF(data)
				if (checkIfCDF == 1) {
					inputTest <- file.access(data, 0)
					if (inputTest == 0) {
						raw_data = xcmsRaw(data)
						sourceFile <- "data"
					} else {
						dlgMessage("The input data specified is not accessible. Please, choose a valid CDF file.")
						data <- isCDFdlg("Select a valid .CDF file.", "The selected file is not a CDF file")
						raw_data = xcmsRaw(data)
						sourceFile <- "data"
					}
				} else {
					dlgMessage("The file specified is not a CDF file. Please, choose a valid CDF file.")
					data <- isCDFdlg("Select a valid .CDF file.", "The selected file is not a CDF file")
					raw_data = xcmsRaw(data)
					sourceFile <- "data"
				}
			} else {
				dlgMessage("The input data specified is not accessible. Please, choose a valid CDF file.")
				data <- isCDFdlg("Select a valid .CDF file.", "The selected file is not a CDF file")
				raw_data = xcmsRaw(data)
				sourceFile <- "data"
			}
		}
	}

	############### Set folder if SAVE == TRUE ####################
	if (save) {
		if (missing(folder)) {
			folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
		} else {
			if (is.character(folder)) {
				isFolder <- file.access(as.character(folder), 0)
				if (isFolder == 0) {
					isFolder <- file.info(folder)
					if (isFolder$isdir != TRUE) {
						message("The folder defined to save the results is not a valid path. Please, point to the folder where the results should be saved.")
						folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
					}
				} else {
					message("The folder defined to save the results is not a valid path. Please, point to the folder where the results should be saved.")
					folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
				}
			} else {
				message("The path to the folder where the results will be saved must be specified as character. Please, point to the folder where the results should be saved.")
				folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
			}
		}
	}

	validateMZLIST <- try(as.numeric(mzListToFilter), TRUE)
	if ("try-error" %in% class(validateMZLIST)) {
		dlgMessage("The mzListToFilter was not defined as a numerical list. It must be defined as a numeric list of fragments to be maintanined in the new CDF file that will be generated. A new dialog box will allow you to select the fragments.")
		validateMZLIST <- as.numeric(dlgList(c(1:1000), multiple = TRUE, title = "Select the fragments to be maintained.")$res)
	}

	if (filterNoise) {
		if (plotGraph){
			par(mfrow = c(1, 2))
		}
		################# FIRST FILTER NOISE #################
		if (missing(limitScan)) {
			if (plotGraph){
				listOfNoiseScan <- findNoise(raw_data, saveGraph = FALSE, plotGraph = TRUE)
			} else {
				listOfNoiseScan <- findNoise(raw_data, saveGraph = FALSE, plotGraph = FALSE)
			}
		} else {
			if (plotGraph){
				listOfNoiseScan <- findNoise(raw_data, saveGraph = FALSE, limitScan = limitScan, plotGraph = TRUE)
			} else {
				listOfNoiseScan <- findNoise(raw_data, saveGraph = FALSE, limitScan = limitScan, plotGraph = FALSE)
			}
		}
		if (length(listOfNoiseScan) > 0) {
			if (ncol(listOfNoiseScan) == 1) {
				listOfNoiseScan <- data.frame(t(listOfNoiseScan))
			}
			if (plotGraph){
				try(plot(raw_data@scantime/60, raw_data@tic, type = "l", main = paste("Filtered chromatogram"), 
				xlab = "RT (min)", ylab = "Intensity", cex.main = 0.7), TRUE)
			}
			listOfNoiseScan[, 1] <- listOfNoiseScan[, 1] * 2
			listOfNoiseScan[, 1] <- round(listOfNoiseScan[, 1])
			listOfNoiseScan[, 1] <- listOfNoiseScan[, 1]/2
			###### For each scan: check if any Ion in the noise is present. If so, subtract it by the intensity value of the noise ####
			wholeMZ <- (raw_data@env$mz) * 2
			wholeMZ <- round(wholeMZ)
			wholeMZ <- wholeMZ/2
			if (nrow(listOfNoiseScan) > 0){
				for (j in 1:nrow(listOfNoiseScan)) {
					raw_data@env$intensity[wholeMZ == listOfNoiseScan[j, 1]] <- raw_data@env$intensity[wholeMZ == 
					listOfNoiseScan[j, 1]] - listOfNoiseScan[j, 2]
				}
			}
			raw_data@env$intensity[raw_data@env$intensity < 0] <- 0
			###### Recalculate TIC ######
			startsIn <- which(raw_data@scanindex == 0)
			startsIn <- startsIn[length(startsIn)]
			for (j in startsIn:length(raw_data@tic)) {
				if (j != length(raw_data@tic)) {
					raw_data@tic[j] <- sum(raw_data@env$intensity[(raw_data@scanindex[j] + 1):(raw_data@scanindex[j + 
						1])], na.rm = TRUE)
				} else {
					raw_data@tic[j] <- sum(raw_data@env$intensity[(raw_data@scanindex[j] + 1):(length(raw_data@env$intensity))], 
						na.rm = TRUE)
				}
			}
		} else {
			if (plotGraph){
				par(mfrow = c(1, 1))
				try(plot(raw_data@scantime/60, raw_data@tic, type = "l", main = paste("Filtered chromatogram"), 
				xlab = "RT (min)", cex.main = 0.7, ylab = "Intensity"), TRUE)
			}
			message("No flat area was found ...")
		}
		################# THEN ELIMINATE FRAGMENTS #############
		if (length(mzListToFilter) > 0) {
			mzToRemove <- raw_data@mzrange
			mzToRemove <- c(mzToRemove[1]:mzToRemove[2])
			mzToRemove <- mzToRemove[which(mzToRemove %in% mzListToFilter)]
			###### For each scan: check if any Ion in the noise is present. If so, subtract it by the intensity value of the noise ####
			if (length(mzToRemove) > 0) {
				message(paste("Removing ions:", paste(mzToRemove, collapse = ","), sep = " "))
				wholeMZ <- (raw_data@env$mz) * 2
				wholeMZ <- round(wholeMZ)
				wholeMZ <- wholeMZ/2
				for (j in 1:length(mzToRemove)) {
					raw_data@env$intensity[wholeMZ == mzToRemove[j]] <- 0
				}
				###### Recalculate TIC ######
				startsIn <- which(raw_data@scanindex == 0)
				startsIn <- startsIn[length(startsIn)]
				for (j in startsIn:length(raw_data@tic)) {
					if (j != length(raw_data@tic)) {
						raw_data@tic[j] <- sum(raw_data@env$intensity[(raw_data@scanindex[j] + 1):(raw_data@scanindex[j + 
							1])], na.rm = TRUE)
					} else {
						raw_data@tic[j] <- sum(raw_data@env$intensity[(raw_data@scanindex[j] + 1):(length(raw_data@env$intensity))], 
							na.rm = TRUE)
					}
				}
			}
		}
		if (plotGraph){
			try(lines(raw_data@scantime/60, raw_data@tic, col = "red"), TRUE)
		}
	} else {
		if (plotGraph){
			par(mfrow = c(1, 1))
			try(plot(raw_data@scantime/60, raw_data@tic, type = "l", main = paste("Filtered chromatogram"), 
			xlab = "RT (min)", cex.main = 0.7, ylab = "Intensity"), TRUE)
		}
		if (length(mzListToFilter) > 0) {
			mzToRemove <- raw_data@mzrange
			mzToRemove <- c(mzToRemove[1]:mzToRemove[2])
			mzToRemove <- mzToRemove[which(mzToRemove %in% mzListToFilter)]
			###### For each scan: check if any Ion in the noise is present. If so, subtract it by the intensity value of the noise ####
			if (length(mzToRemove) > 0) {
				message(paste("Removing ions:", paste(mzToRemove, collapse = ","), sep = " "))
				wholeMZ <- (raw_data@env$mz) * 2
				wholeMZ <- round(wholeMZ)
				wholeMZ <- wholeMZ/2
				for (j in 1:length(mzToRemove)) {
					raw_data@env$intensity[wholeMZ == mzToRemove[j]] <- 0
				}
				###### Recalculate TIC ######
				startsIn <- which(raw_data@scanindex == 0)
				startsIn <- startsIn[length(startsIn)]
				for (j in startsIn:length(raw_data@tic)) {
					if (j != length(raw_data@tic)) {
						raw_data@tic[j] <- sum(raw_data@env$intensity[(raw_data@scanindex[j] + 1):(raw_data@scanindex[j + 
							1])], na.rm = TRUE)
					} else {
						raw_data@tic[j] <- sum(raw_data@env$intensity[(raw_data@scanindex[j] + 1):(length(raw_data@env$intensity))], 
							na.rm = TRUE)
					}
				}
			}
		}
		if (plotGraph){
			try(lines(raw_data@scantime/60, raw_data@tic, col = "red"), TRUE)
		}
	}
	if (plotGraph){
		try(legend("topleft", legend = c("Original TIC", "Filtered TIC"), cex = 0.7, col = c("black", 
		"red"), lty = c(1, 1), title = "", lwd = 3, merge = FALSE, bty = "n"), TRUE)
	}
	if (save) {
		if (sourceFile == "data") {
			fileName <- gsub(".CDF", paste(output, ".CDF", sep = ""), data, ignore.case = TRUE)
			fileName <- basename(fileName)
			fileName <- file.path(folder, fileName)
			try(write.cdf(raw_data, fileName), TRUE)
		}
		if (sourceFile == "xcmsRaw") {
			folderpath <- as.character(raw_data@filepath[1])
			fileName <- gsub(".CDF", paste(output, ".CDF", sep = ""), folderpath, ignore.case = TRUE)
			fileName <- basename(fileName)
			fileName <- file.path(folder, fileName)
			try(write.cdf(raw_data, fileName), TRUE)
		}
	}
	return(raw_data)
}
