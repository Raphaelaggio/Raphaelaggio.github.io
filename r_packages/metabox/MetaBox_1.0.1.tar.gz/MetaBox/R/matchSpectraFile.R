matchSpectraFile <-
function(file, ionLib, searchWindow = 0.2, matchFactor = 0.7, correlation = 0.95, scoreCut = 10, noiseThreshold = 0, 
	save = TRUE, folder, output = "MatchReport", peakFindMethod = 2, invertOutput = TRUE, showGraphs = TRUE, saveGraphs = FALSE) {
	######################################################
	############# Function to check if file is CDF #######
######################################################
isCDFdlg <- function(titleMSG, errorMSG) {
		t = 0
		while (t == 0) {
			checkIfCDF <- dlgOpen(title = titleMSG, multiple = FALSE)$res
			checkIfCDF2 <- basename(checkIfCDF)
			checkIfCDF3 <- unlist(strsplit(checkIfCDF2, "\\."))
			checkIfCDF4 <- checkIfCDF3[length(checkIfCDF3)]
			if (toupper(checkIfCDF4) == "CDF") {
				t = 1
				return(checkIfCDF)
			} else {
				dlgMessage(errorMSG)
			}
		}
	}
	#######################################################
	################# Check if CDF - No dialog box ########
#######################################################
isCDF <- function(pathFile, errorMSG) {
		t = 0
		checkIfCDF <- pathFile
		checkIfCDF2 <- basename(checkIfCDF)
		checkIfCDF3 <- unlist(strsplit(checkIfCDF2, "\\."))
		checkIfCDF4 <- checkIfCDF3[length(checkIfCDF3)]
		if (toupper(checkIfCDF4) == "CDF") {
			t = 1
			return(t)
		} else {
			return(t)
		}
	}
	######################################################
	########## Collect Data ##############################
######################################################  
if (missing(file)) {
		file <- isCDFdlg("Select the CDF file to be analyzed.", "The selected file is not a CDF file.")
		dataGC <- xcmsRaw(file)
	} else {
		if (class(file)[1] == "xcmsRaw") {
			dataGC <- file
			file <- deparse(substitute(file))
		} else {
			verifCDF <- isCDF(file, "The specified file is not a CDF file.")
			if (verifCDF == 1) {
				inputTest <- file.access(file, 0)
				if (inputTest == 0) {
					dataGC <- xcmsRaw(file)
				} else {
					message("The input data file is not accessible. Please choose a valid CDF file.")
					file <- isCDFdlg("Select the CDF file to be analyzed.", "The selected file is not a CDF file.")
					dataGC <- xcmsRaw(file)
				}
			} else {
				message("The selected file is not a CDF file. Please choose a valid CDF file.")
				file <- isCDFdlg("Select the CDF file to be analyzed.", "The selected file is not a CDF file.")
				dataGC <- xcmsRaw(file)
			}
		}
	}	
	######################################################
	########## Collect Folder ############################
###################################################### 
if (save | saveGraphs) {
		if (missing(folder)) {
			folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
		} else {
			if (is.character(folder)) {
				isFolder <- file.access(as.character(folder), 0)
				if (isFolder == 0) {
					isFolder <- file.info(folder)
					if (isFolder$isdir != TRUE) {
						message("The folder defined to save the results is not a valid path.")
						folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
					}
				} else {
					message("The folder defined to save the results is not a valid path.")
					folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
				}
			} else {
				message("The path to the folder where the results will be saved must be specified as character.")
				folder = dlgDir(title = "Select the folder where the output file will be saved.")$res
			}
		}
	}	
	
	######### Check if a CSV or .msl file ############
	isCSVORmsldlg <- function(titleMSG, errorMSG) {
		t = 0
		while (t == 0) {
			checkIfCsv <- dlgOpen(title = titleMSG, multiple = FALSE)$res
			checkIfCsv2 <- basename(checkIfCsv)
			checkIfCsv3 <- unlist(strsplit(checkIfCsv2, "\\."))
			checkIfCsv4 <- checkIfCsv3[length(checkIfCsv3)]
			if (toupper(checkIfCsv4) == "CSV") {
				t = 1
				return(c(checkIfCsv, "csv"))
			} else {
				if (toupper(checkIfCsv4) == "MSL") {
					t = 1
					return(c(checkIfCsv, "msl"))
				} else {
					dlgMessage(errorMSG)
				}
			}
		}
	}
	####################################################
	######### Check if a CSV or .msl file  NO DIALOG BOX ############
isCSVORmsl <- function(pathfile, errorMSG) {
		t = 0
		checkIfCsv2 <- basename(pathfile)
		checkIfCsv3 <- unlist(strsplit(checkIfCsv2, "\\."))
		checkIfCsv4 <- checkIfCsv3[length(checkIfCsv3)]
		if (toupper(checkIfCsv4) == "CSV") {
			t = "csv"
			return(t)
		} else {
			if (toupper(checkIfCsv4) == "MSL") {
				t = "msl"
				return(t)
			} else {
				t = 0
				return(t)
			}
		}
	}
	####################################################  
	##### If no ionLib specified: the user can point to a CSV file or to the .msl file from AMDIS library ####
if (missing(ionLib)) {
		ionLib <- isCSVORmsldlg("Select a CSV file containing the ionLib or the .msl file of the AMDIS library in use.", 
			"The selected file is not a CSV nor a msl file")
		if (ionLib[2] == "csv") {
			ionLibFile <- ionLib[1]
			ionLib = read.csv(ionLib[1], colClass = "character", check.names = FALSE)
			if (ncol(ionLib) != 9) {
				stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
			}
			if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
				message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
				names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
			}
			message("ionLib file loaded...")
		} else {
			ionLibFile <- ionLib[1]
			message("Converting AMDIS library...")
			ionLib <- buildLib(ionLib[1], save = FALSE, verbose = FALSE)
			message("ionLib built and loaded...")
		}
	} else {
		if (is.data.frame(ionLib) == TRUE) {
			if (ncol(ionLib) != 9) {
				stop("The ionLib specified seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
			}
			if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
				message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
				names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
			}
			message("ionLib - Data frame loaded...")
			ionLibFile <- deparse(substitute(ionLib))
		} else {
			if (is.character(ionLib)) {
				checkIfCsv <- isCSVORmsl(ionLib)
				if (checkIfCsv != 0) {
					inputTest <- file.access(ionLib, 0)
					if (inputTest == 0) {
						if (checkIfCsv == "csv") {
							ionLibFile <- ionLib
							ionLib = read.csv(ionLib, colClasses = "character", check.names = FALSE)
							if (ncol(ionLib) != 9) {
								stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
							}
							if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
								message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
								names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
							}
							message("ionLib loaded...")
						} else {
							if (checkIfCsv == "msl") {
								ionLibFile <- ionLib
								message("Converting AMDIS library...")
								ionLib <- buildLib(ionLib, save = FALSE, verbose = FALSE)
								message("ionLib built and loaded...")
							}
						}
					} else {
						dlgMessage("The ionLib specified is not accessible. Please, choose a valid CSV file or msl file to be used as ionLib.")
						ionLib <- isCSVORmsldlg("Select a CSV file containing the ionLib or the .msl file of the AMDIS library in use.", 
							"The selected file is not a CSV nor a msl file")
						if (ionLib[2] == "csv") {
							ionLibFile <- ionLib[1]
							ionLib = read.csv(ionLib[1], colClass = "character", check.names = FALSE)
							if (ncol(ionLib) != 9) {
								stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
							}
							if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
								message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
								names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
							}
							message("ionLib file loaded...")
						} else {
							if (ionLib[2] == "msl") {
								ionLibFile <- ionLib[1]
								message("Converting AMDIS library...")
								ionLib <- buildLib(ionLib[1], save = FALSE, verbose = FALSE)
								message("ionLib built and loaded...")
							}
						}
					}
				} else {
					dlgMessage("The ionLib specified is not a CSV nor msl file. Please, choose a valid CSV file or msl file to be used as ionLib.")
					ionLib <- isCSVORmsldlg("Select a CSV file containing the ionLib or the .msl file of the AMDIS library in use.", 
						"The selected file is not a CSV nor a msl file")
					if (ionLib[2] == "csv") {
						ionLibFile <- ionLib[1]
						ionLib = read.csv(ionLib[1], colClass = "character", check.names = FALSE)
						if (ncol(ionLib) != 9) {
							stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
						}
						if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
							message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
							names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
						}
						message("ionLib file loaded...")
					} else {
						if (ionLib[2] == "msl") {
							ionLibFile <- ionLib[1]
							message("Converting AMDIS library...")
							ionLib <- buildLib(ionLib[1], save = FALSE, verbose = FALSE)
							message("ionLib built and loaded...")
						}
					}
				}
			} else {
				dlgMessage("The ionLib specified is not a character string nor a data frame. Please, choose a valid CSV file or msl file to be used as ionLib.")
				ionLib <- isCSVORmsldlg("Select a CSV file containing the ionLib or the .msl file of the AMDIS library in use.", 
					"The selected file is not a CSV nor a msl file")
				if (ionLib[2] == "csv") {
					ionLibFile <- ionLib[1]
					ionLib = read.csv(ionLib[1], colClass = "character", check.names = FALSE)
					if (ncol(ionLib) != 9) {
						stop("The ionLib selected seems to have a different number of columns than the ionLib used by MetaBox. See data(ionLib) for an example of ionLib.")
					}
					if (sum(names(ionLib) != c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")) > 0) {
						message("The column names of the ionLib selected does not match the expected names of an ionLib used by MetaBox. We will try to modify the column names. See data(ionLib) for an example of the expected column names.")
						names(ionLib) <- c("Compound", "ERT", "M1", "M2", "M3", "M4", "R2", "R3", "R4")
					}
					message("ionLib file loaded...")
				} else {
					if (ionLib[2] == "msl") {
						ionLibFile <- ionLib[1]
						message("Converting AMDIS library...")
						ionLib <- buildLib(ionLib[1], save = FALSE, verbose = FALSE)
						message("ionLib built and loaded...")
					}
				}
			}
		}
	}

	ionLib[2] <- as.numeric(as.character(ionLib[, 2]))
	######################################
	######### Find Peaks Method 1 ########
######################################
peakFind <- function(x, y) {
		rt <- c()
		iValue <- c()
		for (i in 3:(length(y) - 2)) {
			nextValue <- y[i + 2]
			previousValue <- y[i - 2]
			if (length(nextValue) > 0 && length(previousValue) > 0) {
				if ((previousValue) < y[i] & y[i] > (nextValue)) {
					rt <- c(rt, x[i])
					iValue <- c(iValue, y[i])
				}
			}
		}
		return(data.frame(rt = rt, intensity = iValue, stringsAsFactors = FALSE))
	}
	potentialPeaks <- function(SmoothedCurve, nonSmoothedCurve) {
		peaksFound <- peakFind(as.numeric(as.character(SmoothedCurve[, 1])), as.numeric(as.character(SmoothedCurve[, 
			2])))
		if (nrow(peaksFound) > 0) {
			rtsPeakFound <- round(peaksFound[, 1], 2)
			rtNonSmooth <- round(nonSmoothedCurve[, 1], 2)
			rowsIon <- which(rtNonSmooth %in% rtsPeakFound)
			peaksFound <- nonSmoothedCurve[c(rowsIon), ]
			peaksFound <- peaksFound[!is.na(peaksFound[, 1]), ]
			peaksFound <- peaksFound[!is.na(peaksFound[, 2]), ]
			peaksFound <- peaksFound[peaksFound[, 2] != 0, ]
			return(peaksFound)
		} else {
			peaksFound <- data.frame()
			return(peaksFound)
		}
	}
	######################################
	######### Find Peaks Method 2 ########
######################################
potentialPeaks2 <- function(smoothedData, nonSmoothedData) {
		FindPeaks <- predict(smoothedData, deriv = 1)
		potPeak <- data.frame(set1 = FindPeaks$y > 0)
		potPeak$set2 <- FindPeaks$y[c(2:length(FindPeaks$y), 1)] > 0
		potPeak$peak <- apply(potPeak, 1, function(x) (x[1] == TRUE && x[2] == FALSE))
		PeaksFound <- nonSmoothedData[which(potPeak$peak == TRUE) + 1, ]
		PeaksFound <- PeaksFound[!is.na(PeaksFound[, 1]), ]
		return(PeaksFound)
	}
	#####################################################################################
	##################### Identify compound from library ################################
#####################################################################################
if (showGraphs | saveGraphs){
	initPar <- par()
	dev.off()
}

message("Looking for compounds. Please wait...")
  
findCPD <- function(CDFdata, libRow, peakFindMethod = peakFindMethod, returnOption = returnOption, noiseThreshold = noiseThreshold, ...) {
		compoundFound <- c()
		imfs <- as.numeric(libRow[1,3:6])
		imfs[is.na(imfs)] <- 0
		RTTarget <- c(as.numeric(libRow[1, 2]) - searchWindow, as.numeric(libRow[1, 2]) + searchWindow) 	
		ionFinalT <- lapply(as.list(imfs), function(x) extract_ion(CDFdata, as.numeric(x), timeWindow = RTTarget))	
		ionFinalTframe <- as.data.frame(ionFinalT, stringsAsFactors = FALSE)
		ionFinalTframe <- ionFinalTframe[c(1,2,4,6,8)]
		nasFound <- apply(ionFinalTframe, 1, function(x) sum(is.na(x)))
		nasFound <- which(nasFound == 5)
		if (length(nasFound) > 0){
			ionFinalT <- lapply(ionFinalT, function(x) x[-nasFound,])
			ionFinalTframe <- ionFinalTframe[-nasFound,]
		}
		if (nrow(ionFinalTframe) > 0){
			###### Plot graph ########
			if (showGraphs == FALSE && saveGraphs){
				folderPath <- file.path(folder, "MetaBoxGraphOutput")
				isFolder <- file.access(as.character(folderPath), 0)
				if (isFolder == 0) {
					isFolder <- file.info(folderPath)
					if (isFolder$isdir) {
						#do nothing
					} else {
						dir.create(folderPath)
					}
				} else {
					dir.create(folderPath)
				}
				name.file <- basename(file)
				confirmCDF <- grep(".CDF", toupper(name.file), fixed = TRUE)
				if (length(confirmCDF) > 0){
					name.file <- gsub(".cdf", paste("_", libRow[1, 1], ".pdf", sep = ""), name.file, fixed = FALSE, ignore.case = TRUE)
				} else {
					name.file <- paste(name.file, "_", libRow[1, 1], ".pdf", sep = "")
				}
				graphNameChrom <- file.path(folderPath, name.file)
				pdf(graphNameChrom)
				suppressWarnings(par(initPar))
				toPlot <- which(round(CDFdata@scantime) %in% round(ionFinalTframe[, 1] * 60))
				plot(CDFdata@scantime[toPlot]/60, CDFdata@tic[toPlot], xlab = "RT(min)", ylab = "Intensity", main = paste("Searching for ", libRow[1, 1], " in ", basename(file), sep = ""), col = "grey", type = "l", ylim = c(-50, max(CDFdata@tic[toPlot], na.rm = TRUE)), cex.main = 0.7, bty = "n", cex.axis = 0.6, las = 1)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 2], type = "l", col = "firebrick3"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 3], type = "l", col = "dodgerblue4"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 4], type = "l", col = "forestgreen"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 5], type = "l", col = "goldenrod3"), TRUE)
				try(legend("topleft", legend = c("TIC", libRow[1, c(3:6)]), cex = 0.5, col = c("grey", "firebrick3", "dodgerblue4", "forestgreen", "goldenrod3"), lty = c(1, 1, 1, 1, 1), title = "Fragments", lwd = 3, merge = FALSE, bty = "n"), TRUE)
			}	
			if (showGraphs){
				suppressWarnings(par(initPar))
				toPlot <- which(round(CDFdata@scantime) %in% round(ionFinalTframe[, 1] * 60))
				plot(CDFdata@scantime[toPlot]/60, CDFdata@tic[toPlot], xlab = "RT(min)", ylab = "Intensity", main = paste("Searching for ", libRow[1, 1], " in ", basename(file), sep = ""), col = "grey", type = "l", ylim = c(-50, max(CDFdata@tic[toPlot], na.rm = TRUE)), cex.main = 0.7, bty = "n", cex.axis = 0.6, las = 1)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 2], type = "l", col = "firebrick3"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 3], type = "l", col = "dodgerblue4"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 4], type = "l", col = "forestgreen"), TRUE)
				try(lines(ionFinalTframe[, 1], ionFinalTframe[, 5], type = "l", col = "goldenrod3"), TRUE)
				try(legend("topleft", legend = c("TIC", libRow[1, c(3:6)]), cex = 0.5, col = c("grey", "firebrick3", "dodgerblue4", "forestgreen", "goldenrod3"), lty = c(1, 1, 1, 1, 1), title = "Fragments", lwd = 3, merge = FALSE, bty = "n"), TRUE)
			}
			##########################	
			###############################################################
			### At least 3 ions of the spectral library must be present ###
			###############################################################
			noIMFS <- apply(ionFinalTframe[-1], 1, function(x) sum(x == 0))
			noIMFS <- which(noIMFS >= 2)
			if (length(noIMFS) > 0){
				ionFinalT <- lapply(ionFinalT, function(x) x[-noIMFS,])
				ionFinalTframe <- ionFinalTframe[-noIMFS,]
			}
			if (nrow(ionFinalTframe) != 0){	
				# Data sets: ionFinalT as list/ ionFinalTframe as data frame
				# Peaks: peaksFound1 = row number / peaksFound2 = RT / rtsPeakFound = data frame with all the peaks of all 4 IMFs analysed.
				if (peakFindMethod == 1) {
					ionFinal <- lapply(ionFinalT, function(x) spline(x[, 1], x[, 2], method = "fmm"))
					ionFinal <- as.data.frame(ionFinal, stringsAsFactors = FALSE)
					ionFinal <- ionFinal[c(1,2,4,6,8)]
					ionFinal <- apply(ionFinal[-1], 2, function(x) peakFind(ionFinal[, 1], x))
					peaksFound <- lapply(ionFinal, function(x) x$rt)		
					if (length(peaksFound[[1]]) > 0) {
						nPeaks <- lapply(peaksFound, function(x) length(x))
						nPeaks <- which(nPeaks > 0)
						peaksFound <- peaksFound[nPeaks]
						peaksFound <- lapply(peaksFound, function(x) round(x, 2))
						rtNonSmooth <- round(ionFinalTframe[, 1], 2)
						peaksFound1 <- lapply(peaksFound, function(x) which(rtNonSmooth %in% x))
						peaksFound2 <- lapply(peaksFound1, function(x) rtNonSmooth[x])
						rtsPeakFound <- as.numeric(unlist(peaksFound1))
						rtsPeakFound <- rtsPeakFound[!duplicated(rtsPeakFound)]
						rtsPeakFound <- rtsPeakFound[order(rtsPeakFound)]
						rtsPeakFound <- ionFinalTframe[as.numeric(rtsPeakFound),]	
					} else {
						rtsPeakFound <- data.frame()
					}							
				}
				if (peakFindMethod == 2) {
					ionFinal <- lapply(ionFinalT, function(x) smooth.spline(x[, 1], x[, 2]))
					ionFinal <- lapply(ionFinal, function(x) predict(x, deriv = 1))
					SearchForPeaks <- function(data){
						potPeak <- data.frame(set1 = data$y > 0)
						potPeak$set2 <- data$y[c(2:length(data$y), 1)] > 0
						potPeak$peak <- apply(potPeak, 1, function(x) (x[1] == TRUE && x[2] == FALSE))
						peaksFound <- c(which(potPeak$peak == TRUE))
						peaksFound <- round(data$x[peaksFound],2)
						return(peaksFound)
					}
					peaksFound <- lapply(ionFinal, function(x) SearchForPeaks(x))
					rtNonSmooth <- round(ionFinalTframe[, 1], 2)
					peaksFound1 <- lapply(peaksFound, function(x) which(rtNonSmooth %in% x))
					peaksFound2 <- lapply(peaksFound1, function(x) rtNonSmooth[x])			
					rtsPeakFound <- as.numeric(unlist(peaksFound1))
					rtsPeakFound <- rtsPeakFound[!duplicated(rtsPeakFound)]
					rtsPeakFound <- rtsPeakFound[order(rtsPeakFound)]
					rtsPeakFound <- ionFinalTframe[as.numeric(rtsPeakFound),]
				}
				if (peakFindMethod == 3) {
					ionFinal <- lapply(ionFinalT, function(x) spline(x[, 1], x[, 2], method = "fmm"))
					SearchForPeaks2 <- function(data){
						dataSizeWave <- data.frame(Size = c(16,rep(32,2),rep(64,4), rep(128,8), rep(256,16), rep(512,32), 1024), wavelimit = c(1:64), stringsAsFactors = FALSE)
						dataToWave <- as.numeric(data$y)
						if (sum(dataToWave == 0) == length(dataToWave)){
							peaksFound <- 0
						} else {	
							waveLimit <- which(dataSizeWave[,1] <= length(dataToWave))	
							scales <- dataSizeWave[waveLimit, 2]
							wCoefs <- cwt(dataToWave, scales = scales, wavelet = "mexh")	
							wCoefs <- cbind(dataToWave, wCoefs)	
							colnames(wCoefs) <- c(0,scales)	
							localMax <- getLocalMaximumCWT(wCoefs)
							ridgeList <- getRidge(localMax)
							majorPeakInfo <- identifyMajorPeaks(dataToWave, ridgeList, wCoefs, SNR.Th = 3, nearbyPeak = TRUE)
							peaksFound <- majorPeakInfo$potentialPeakIndex
							peaksFound <- round(data$x[peaksFound], 2)
						}
						return(peaksFound)
					}
					peaksFound <- lapply(ionFinal, function(x) SearchForPeaks2(x))
					rtNonSmooth <- round(ionFinalTframe[, 1], 2)
					peaksFound1 <- lapply(peaksFound, function(x) which(rtNonSmooth %in% x))
					peaksFound2 <- lapply(peaksFound1, function(x) rtNonSmooth[x])			
					rtsPeakFound <- as.numeric(unlist(peaksFound1))
					rtsPeakFound <- rtsPeakFound[!duplicated(rtsPeakFound)]
					rtsPeakFound <- rtsPeakFound[order(rtsPeakFound)]
					rtsPeakFound <- ionFinalTframe[as.numeric(rtsPeakFound),]
				}
				if(nrow(rtsPeakFound) > 0){		
					for (i in 2:5){
						rtsPeakFound[rtsPeakFound[,i] < noiseThreshold, i] <- NA
					}		
					rowsToRemove <- apply(rtsPeakFound[2:5], 1, function(x) sum(is.na(x)))
					rowsToRemove <- which(rowsToRemove > 1)
					if (length(rowsToRemove) > 0){
						rtsPeakFound <- rtsPeakFound[-rowsToRemove,]
					}
					if(nrow(rtsPeakFound) > 0){
						######################		
						####### Stage 2 ######
						######################
						getRatioSimilarity <- function(x, theoryRatio){
							observedRatio <- x[2]/x[1]
							ratio <- min(c(theoryRatio, observedRatio), na.rm = TRUE)/max(c(theoryRatio, observedRatio), na.rm = TRUE)
							if (is.na(ratio)){
								ratio <- 0
							}
							return(ratio)
						}
						ratio1 <- apply(rtsPeakFound[c(2,3)], 1, function(x) getRatioSimilarity(x, as.numeric(libRow$R2[1])))
						ratio2 <- apply(rtsPeakFound[c(2,4)], 1, function(x) getRatioSimilarity(x, as.numeric(libRow$R3[1])))
						ratio3 <- apply(rtsPeakFound[c(2,5)], 1, function(x) getRatioSimilarity(x, as.numeric(libRow$R4[1])))				
						rtsPeakFound$Score <- unlist(lapply(ratio1, function(x) sum(x >= matchFactor)))
						rtsPeakFound$Score <- rtsPeakFound$Score + unlist(lapply(ratio2, function(x) sum(x >= matchFactor)))
						rtsPeakFound$Score <- rtsPeakFound$Score + unlist(lapply(ratio3, function(x) sum(x >= matchFactor)))
						rtsPeakFound <- rtsPeakFound[rtsPeakFound$Score > 0,]		
						if (nrow(rtsPeakFound) > 0){
							ionFinalTframe <- ionFinalTframe[ionFinalTframe[,1] %in% rtsPeakFound[,1],]
							######################		
							####### Stage 1 ######
							######################
							ScoreStage1 <- function(data, peaksFound2, ionFinalTframe){
								dataRT <- round(data[1], 2)
								Score1 <- sum(unlist(lapply(peaksFound2, function(x) sum(dataRT %in% x))))
								Score2 <- sum(data[2:5] != 0, na.rm = TRUE)
								MaxValues <- apply(ionFinalTframe[2:5], 2, function(x) round(x[which(x == max(x, na.rm = TRUE))], 2))
								MaxValues <- lapply(MaxValues, function(x) x = x[!duplicated(x)])
								Score3 <- sum(data[2:5] == MaxValues, na.rm = TRUE)
								Score <- Score1 + Score2 + Score3
								return(Score)	
							}
							rtsPeakFound$Score <- rtsPeakFound$Score + apply(rtsPeakFound, 1, function(x) ScoreStage1(x, peaksFound2, ionFinalTframe))	
							######################		
							####### Stage 3 ######
							######################
							getScoreCorrelation <- function(data, imfs){
								data <- round(data[1], 2)
								RTTarget <- c(data - 0.07, data + 0.07) 
								AllIons <- lapply(as.list(imfs), function(x) extract_ion(CDFdata, as.numeric(x), RTTarget))
								AllIonsFrame <- as.data.frame(AllIons, stringsAsFactors = FALSE)
								AllIonsFrame <- AllIonsFrame[c(2,4,6,8)]
								Correlation <- apply(AllIonsFrame[-1], 2, function(x) suppressWarnings(cor(x, AllIonsFrame[1])))
								Correlation[is.na(Correlation)] <- 0
								return(Correlation)
							}
							rtsPeakFound$Score <- rtsPeakFound$Score + unlist(apply(rtsPeakFound[1], 1, function(x) sum(getScoreCorrelation(x, imfs) >= correlation)))
							ionFinalTframe <- ionFinalTframe[ionFinalTframe[,1] %in% rtsPeakFound[,1],]					
							if (showGraphs | saveGraphs){
								try(text(ionFinalTframe[, 1], ionFinalTframe[, 2], labels = rtsPeakFound$Score, cex = 0.5, col = "grey"), TRUE)
							}
							#####################################
							### Select RT with the best Score ###
							#####################################
							rtsPeakFound <- rtsPeakFound[which(rtsPeakFound$Score == max(rtsPeakFound$Score, na.rm = TRUE)) ,]				
							###########################################################
							### Calculate the diff between observed and expected RT ###
							###########################################################
							rtsPeakFound$RTDiff <- unlist(apply(rtsPeakFound[1], 1, function(x) abs(as.numeric(x) - as.numeric(libRow[1,2]))))
							if (nrow(rtsPeakFound) > 1){	
								rtsPeakFound <- rtsPeakFound[rtsPeakFound $RTDiff == min(rtsPeakFound$RTDiff, na.rm = TRUE), ]
							}			
							ionFinalTframe <- ionFinalTframe[ionFinalTframe[,1] %in% rtsPeakFound[1,1],]					
							############ Add compound name to graph #######
							if (showGraphs | saveGraphs){
								maxIon <- max(ionFinalTframe[1, 2], na.rm = TRUE)
								if (maxIon < (max(CDFdata@tic[toPlot], na.rm = TRUE)/2)) {
									distSeg2 <- max(CDFdata@tic[toPlot], na.rm = TRUE)/6
								} else {
									distSeg2 <- maxIon/10
								}
								try(segments(ionFinalTframe[1, 1], ionFinalTframe[1, 2], ionFinalTframe[1, 1], (ionFinalTframe[1, 2] + (distSeg2)), col = "red", lty = 3), TRUE)
								try(text(ionFinalTframe[1, 1], (ionFinalTframe[1, 2] + (distSeg2 * 1.1)), labels = paste(as.character(libRow[1, 1]), "[", ionFinalTframe[1, 1], "]", sep = " "), cex = 0.35), TRUE)					
								############# Add bar graph to figure ######					
								par(fig = c(0.6, 1, 0.5, 0.95), mar = c(5, 5, 2, 1), new = T, xpd = T)
								dataToPlot <- t(cbind(c(1, libRow[1, 7], libRow[1, 8], libRow[1, 9]), c(1, ionFinalTframe[1, 3]/ionFinalTframe[1, 2], ionFinalTframe[1, 4]/ionFinalTframe[1, 2], ionFinalTframe[1, 5]/ionFinalTframe[1, 2])))
								dataToPlot[dataToPlot > 1] <- 1
								try(barplot(as.numeric(dataToPlot), col = c("black", "firebrick3", "black", "dodgerblue4", "black", "forestgreen", "black", "goldenrod3"), beside = TRUE, cex.axis = 0.3, cex.main = 0.5, border = NA, main = "Spectra match"), TRUE)
								points(2.05, -0.1, pch = 15)
								text(2.05, -0.1, "Expected intensity", cex = 0.6, pos = 4)
							}
							if (showGraphs && saveGraphs) {
								folderPath <- file.path(folder, "MetaBoxGraphOutput")
								isFolder <- file.access(as.character(folderPath), 0)
								if (isFolder == 0) {
									isFolder <- file.info(folderPath)
									if (isFolder$isdir) {
										#do nothing
									} else {
										dir.create(folderPath)
									}
								} else {
									dir.create(folderPath)
								}
								name.file <- basename(file)
								confirmCDF <- grep(".CDF", toupper(name.file), fixed = TRUE)
								if (length(confirmCDF) > 0){
									name.file <- gsub(".cdf", paste("_", libRow[1, 1], ".pdf", sep = ""), name.file, fixed = FALSE, ignore.case = TRUE)
								} else {
									name.file <- paste(name.file, "_", libRow[1, 1], ".pdf", sep = "")
								}
								graphNameChrom <- file.path(folderPath, name.file)
								dev.copy2pdf(file = graphNameChrom)
							}
							if (showGraphs == FALSE && saveGraphs == TRUE){
								dev.off()
							}
							compoundFound <- data.frame(Name = libRow[1, 1], RetTime = as.numeric(rtsPeakFound[1, 1]), diffTime = round(as.numeric(rtsPeakFound$RTDiff), 3), Score = as.numeric(rtsPeakFound$Score), Intensity = as.numeric(rtsPeakFound[1, 2]), stringsAsFactors = FALSE)
							if (returnOption == 1){
								compoundFound2 <- data.frame(c(libRow[1, 1], rtsPeakFound[1,]), stringsAsFactors = FALSE)
								names(compoundFound2) <- c("Name", "RetTime", "Ion1", "Ion2", "Ion3", "Ion4", "Score", "RTDiff")
								return(compoundFound2)
							} else {
								return(compoundFound)
							}
						} else {
							if (showGraphs == FALSE && saveGraphs == TRUE){
								dev.off()
							}
						}
					} else {
						if (showGraphs == FALSE && saveGraphs == TRUE){
							dev.off()
						}
					}	
				} else {
					if (showGraphs == FALSE && saveGraphs == TRUE){
						dev.off()
					}
				}
			} else {
				if (showGraphs == FALSE && saveGraphs == TRUE){
					dev.off()
				}
			}
		}
	}
    #############################################################################
	######### Check if there is any peak for each compound in the library #######
	#############################################################################
	IdentfyCPDSingle <- function(dataGC, ionLib, peakFindMethod, returnOption, noiseThreshold, ...){
		preReport <- apply(ionLib, 1, function(x) findCPD(dataGC, data.frame(t(x), stringsAsFactors = FALSE), returnOption = returnOption, peakFindMethod = peakFindMethod, noiseThreshold = noiseThreshold))
		preReport <- do.call(rbind, preReport)
		### Remove duplicated compounds per RT ###
		preReport <- preReport[!duplicated(preReport), ]
		dupli <- preReport[duplicated(preReport[2]), ]
		dupliRT <- dupli[, 2]
		dupliRT <- dupliRT[!duplicated(dupliRT)]
		if (length(dupliRT) > 0) {
			for (d in 1:length(dupliRT)) {
				toDecide <- preReport[preReport[2] == dupliRT[d], ]
				toDelete <- row.names(toDecide)
				toDecide <- toDecide[toDecide$Score == max(toDecide$Score, na.rm = TRUE), ]
				if (nrow(toDecide) > 1) {
					toDecide <- toDecide[toDecide$diffTime == min(toDecide$diffTime, na.rm = TRUE), ]
				}
				if (nrow(toDecide) > 1) {
					toDecide <- toDecide[1, ]
				}
				deleteComp <- which(toDelete != row.names(toDecide))
				preReport <- preReport[-c(which(row.names(preReport) %in% toDelete[deleteComp])), ]
			}
		}
		return(preReport)
	}
		
	####################################################################################################################
	######### For each GC-MS file, load the data and check if there is any peak for each compound in the library #######
	####################################################################################################################	
	finalData <- IdentfyCPDSingle(dataGC, ionLib, peakFindMethod = peakFindMethod, returnOption = 2, noiseThreshold = noiseThreshold, folder = folder, saveGraphs = saveGraphs, showGraphs = showGraphs)

	#######################################
	######### Generate total report #######
	#######################################
	finalDataBig <- finalData
	names(finalDataBig) <- c("Name", paste("RT", basename(file), sep = "_"), paste("DiffRT", basename(file), sep = "_"), paste("Score", basename(file), sep = "_"), basename(file))
	
	########################################
	######### Generate cutoff report #######
	########################################
	finalDataSmall <- finalData[finalData$Score >= scoreCut,]
	finalDataSmall <- finalDataSmall[c(1,5)]
	names(finalDataSmall)[2] <- basename(file)
	
	if(invertOutput){
		finalDataBig <- data.frame(t(finalDataBig), stringsAsFactors = FALSE, check.names = FALSE)
		names(finalDataBig) <- finalDataBig[1,]
		finalDataBig <- finalDataBig[-1,]
		
		finalDataSmall <- data.frame(t(finalDataSmall), stringsAsFactors = FALSE, check.names = FALSE)
		names(finalDataSmall) <- finalDataSmall[1,]
		finalDataSmall <- finalDataSmall[-1,]
	}
	logFile <- data.frame(DataFolder = "none", File = file, SearchWindow = searchWindow, MatchFactor = matchFactor, Correlation = correlation, ScoreCut = scoreCut, Library = ionLibFile, DynamicLibrary = "none", ScoreCutDynamicLibrary = "none", NoiseThreshold = noiseThreshold, PeakFindMethod = peakFindMethod, stringsAsFactors = FALSE)
	if (save == TRUE) {
		sheet <- output
		store <- file.path(folder, paste(sheet, "Total.csv", sep = ""))
		inputTest <- file.access(store, 0)
		if (inputTest == 0){
			addFile <- 1
			while(inputTest == 0){
				store <- file.path(folder, paste(sheet, "Total", addFile, ".csv", sep = ""))
				inputTest <- file.access(store, 0)
				addFile <- addFile + 1
			}
		}
		
		if(invertOutput){
			write.csv(finalDataBig, file = store, row.names = TRUE)
		} else {
			write.csv(finalDataBig, file = store, row.names = FALSE)
		}
		bidGata <- store
		sheet <- output
		store <- file.path(folder, paste(sheet, "CutOff.csv", sep = ""))
		inputTest <- file.access(store, 0)
		if (inputTest == 0){
			addFile <- 1
			while(inputTest == 0){
				store <- file.path(folder, paste(sheet, "CutOff", addFile, ".csv", sep = ""))
				inputTest <- file.access(store, 0)
				addFile <- addFile + 1
			}
		}
		if(invertOutput){
			write.csv(finalDataSmall, file = store, row.names = TRUE)
		} else {
			write.csv(finalDataSmall, file = store, row.names = FALSE)
		}
		smallData <- store
		sheet <- paste("logFile", output, sep = "_")
		store <- file.path(folder, paste(sheet, ".csv", sep = ""))
		inputTest <- file.access(store, 0)
		if (inputTest == 0){
			addFile <- 1
			while(inputTest == 0){
				store <- file.path(folder, paste(sheet, addFile, ".csv", sep = ""))
				inputTest <- file.access(store, 0)
				addFile <- addFile + 1
			}
		}
		write.csv(logFile, file = store, row.names = FALSE)
		logData <- store
		message("Done!")
		message(paste("The following files were saved in ", folder, ":", sep = ""))
		pandoc.table(data.frame(OutputFiles = c(bidGata, smallData, logData), stringsAsFactors = FALSE))
	} else {
		message("No file was saved because the argument save was set as FALSE")
	}
	Report <- list(finalDataBig, finalDataSmall, ionLib, logFile)
	names(Report) <- c("Total", "cutOff", "ionLib", "logFile")
	return(Report)
}
