######## Test filterCDF ###########
test_filterCDF <- function (){
	CDFfile <- xcmsRaw(unzip(system.file("extdata/130513_REF_SOL2_2_50_50_1.CDF.zip", package = "MetaBox")))
    filteredData <- filterCDF(CDFfile, filterNoise = TRUE, mzListToFilter = c(40,45,48:80), save = FALSE, plotGraph = FALSE)
   	checkEqualsNumeric(as.numeric(filteredData@tic[500]), 507990)
}