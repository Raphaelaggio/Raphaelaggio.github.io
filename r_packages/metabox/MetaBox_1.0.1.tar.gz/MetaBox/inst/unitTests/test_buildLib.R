######## Test buildLib ###########
test_buildLib <- function (){
    data(exampleMSLfile)
    library <- buildLib(exampleMSLfile, save = FALSE, verbose = FALSE)
    checkEqualsNumeric(as.numeric(library[1,3]), 31)
}
