######## Test matchSpectra ###########
test_matchSpectra <- function (){
	data(exampleIonLib)
	CDFfile <- xcmsRaw(unzip(system.file("extdata/130513_REF_SOL2_2_50_50_1.CDF.zip", package = "MetaBox")))
    exampleTest <- matchSpectraFile(CDFfile, exampleIonLib, scoreCut = 12, save = FALSE, showGraphs = FALSE, saveGraphs = FALSE)
   	checkEqualsNumeric(as.numeric(exampleTest$cutOff[1,1]), 201696289)
}