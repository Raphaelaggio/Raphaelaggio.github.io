######## Test TotalReport ###########
test_TotalReport <- function (){
    data(exampleMatchSpectraInverted)
    testFilter <- filterTotalReport(exampleMatchSpectraInverted$Total, scoreCut = 16, save = FALSE)
    checkEqualsNumeric(as.numeric(testFilter$cutOff[1,4]), 247545856)
}
