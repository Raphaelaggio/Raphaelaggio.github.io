### R code from vignette source 'MetaBoxPackage.Rnw'

###################################################
### code chunk number 1: LoadIonLib
###################################################
library(MetaBox)
library(pander)
panderOptions('table.split.table', Inf)
data(exampleIonLib)
pander(exampleIonLib)


###################################################
### code chunk number 2: MatchReportTotal
###################################################
library(MetaBox)
library(pander)
panderOptions('table.split.table', Inf)
data(exampleMatchSpectra)
toPlot <- exampleMatchSpectra$Total
toPlot <- toPlot[1:5]
row.names(toPlot) <- NULL
names(toPlot) <- c("Name", "RT_Sample1", "DiffRT_Sample1", "Score_Sample1", "Sample1")
pander(toPlot)


###################################################
### code chunk number 3: MatchReporCutOff
###################################################
library(MetaBox)
library(pander)
panderOptions('table.split.table', Inf)
data(exampleMatchSpectra)
toPlot <- exampleMatchSpectra$cutOff
toPlot <- toPlot[1:7]
row.names(toPlot) <- NULL
names(toPlot) <- c("Name", "Sample1", "Sample2", "Sample3", "Sample6", "Sample7", "Sample8")
pander(toPlot)


###################################################
### code chunk number 4: sessioninfo
###################################################
print(sessionInfo(), locale = FALSE)


